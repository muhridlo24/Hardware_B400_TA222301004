from witmotion import IMU
import threading
import logging
import time
import math

#logging.basicConfig(level=logging.DEBUG)

viblist = []
start_time = time.monotonic()

def callback(msg):
    pass

def update_viblist():
    global viblist
    global start_time
    while True:
        acc_radial = math.sqrt(imu.get_acceleration()[0]**2 + imu.get_acceleration()[1]**2)
        elapsed_time = time.monotonic() - start_time
        if elapsed_time >= 1/200:
            viblist.append(acc_radial)
            start_time = time.monotonic()

imu = IMU('/dev/ttySC1', 115200)
imu.set_update_rate(200)
imu.subscribe(callback)

viblist_thread = threading.Thread(target=update_viblist)
viblist_thread.daemon = True
viblist_thread.start()

timer = time.monotonic()
while True:
    if (time.monotonic() - timer) >= 1.0:
        print(len(viblist))
        print(viblist)
        viblist = []
        timer = time.monotonic()
