
##########
'''MAIN SERVER CODE'''
##########

import os
import sys
import time
import math
import json
import socket
import select
import logging
import threading
import numpy as np
import RPi.GPIO as GPIO
from datetime import datetime
from collections import deque
from witmotion import IMU

from panel_lamp import check_internet
import sensor_temp
from sensor_rpm import read_rpm

##CHECK CONNECTION
def check_internet_periodically(pin_num, interval):
    check_internet(pin_num)
    threading.Timer(interval, check_internet_periodically, args=(pin_num, interval)).start()

#VIBRATION CALLBACK UPDATE
def callback(msg):
	global imu
	imu.get_acceleration()

def read_vib():
	global imu
	imu.subscribe(callback)
	acc_radial = math.sqrt(((imu.last_a[0]**2) + (imu.last_a[1]**2)))
	return acc_radial
	
# def read_vib():
    # global imu
    # fail_vib=1.0
    # imu.subscribe(callback)
    
    # if imu.last_a is None:
        # return fail_vib  # Return None if the value is None
    
    # acc_radial = math.sqrt(imu.last_a[0]**2 + imu.last_a[1]**2)
    # return acc_radial

#VIBRATION IN DIFFERENT THREAD
def vibration_list():
	global imu
	global timer
	#global vib_list
	global vibration_values
	imu = IMU('/dev/ttySC1', 115200)
	imu.set_update_rate(200)
	while True:
	    #APPEND VIB_LIST
	    vibration_values.append(read_vib())
	    time.sleep(0.005)

#SERVER DATA LIBRARY
'''coba join tidak dipakai agar lebih cepat kirim data'''		
def collect_data():
	print('DATA COLLECTED')
	global vibration_values
	global target,output
	#global vib_list
	temperature = 0.0
	target = 0.0
	output = 0.0
	#rpm = 0.0
	temperature = sensor_temp.read_temp()
	#rpm = sensor_rpm.read_rpm()
	
	#DATA FORMAT AND DUMP
	data ={
		"LHL01":{
		"timestamp": datetime.now().isoformat("@", "seconds"),
		"performance_log": 
			{
			"temperature": temperature,
			"rpm": [target,output],
			#"rpm":[np.random.uniform(2800,2900),np.random.uniform(2800,2900)],
			#"vibration": ",".join(map(str, vib_list))
			"vibration": ",".join(map(str, vibration_values))
			}
		}
	}
	data = json.dumps(data)
	#print(data)
	#print(f"Length: {len(vibration_values)}")
	return data

def send_data_to_client(client_socket):
    global vibration_values
    try:
        while True:
            # Start time for measuring elapsed time
            start_time = time.time()
            print(start_time)
            
            # PROCESS DATA
            msg_from_server = collect_data()
            
            # SEND RESPONSE TO CLIENT
            client_socket.sendall(msg_from_server.encode('utf-8'))
            
            # WAIT FOR ACKNOWLEDGMENT FROM CLIENT
            acknowledgment = client_socket.recv(1024).decode('utf-8')
            
            # Calculate elapsed time
            elapsed_time = time.time() - start_time
            print("Elapsed time:", elapsed_time)            
            
            if acknowledgment != "ACK":
                print("Failed to receive acknowledgment from client.")
                break
                
            if elapsed_time > 1:
                print("Timeout occurred. Elapsed time:", elapsed_time)
                continue           
            vibration_values.clear()           
            print('aa')           
                            
    except Exception as e:
        print('An error occurre:', str(e))

    # CLOSE CLIENT CONNECTION
    client_socket.close()

#SERVER TCP COMMUNICATION
'''rencana mau coba TCP biar lebih pasti direspon karena in order'''
def my_server():
    # SETUP
    ServerPort = 3333
    ServerIP = "10.129.9.162"

    # CREATE SOCKET
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((ServerIP, ServerPort))
    server_socket.listen(1)

    # SERVER INDICATOR
    print('---')
    print('SERVER NOW IS UP')
    print('---')

    while True:
        try:
            # Start time for measuring elapsed time
            start_time = time.time()
            			
            # ACCEPT CLIENT CONNECTION
            client_socket, address = server_socket.accept()
            print('Accepted connection from:', address)

            # Set a timeout for the client socket
            client_socket.settimeout(1)  # Set the desired timeout value in seconds

            # Start a separate thread to send data to the client
            data_thread = threading.Thread(target=send_data_to_client, args=(client_socket,))
            data_thread.start()
            
            # Calculate elapsed time
            elapsed_time = time.time() - start_time
            print("Server loop elapsed time:", elapsed_time)                        
            
        except socket.timeout:
            print('Client connection timed out.')
       
        except Exception as e:
            print('An error occurred:', str(e))
            
    # CLOSE SERVER SOCKET
    server_socket.close()
    
if __name__ == '__main__':
	#global vib_list
	global vibration_values
	global imu
	global timer
	global running
	global target,output
	'''belum fail safe jika data kosong dan jika wifi mati'''
	VIBRATION_BUFFER_SIZE = 200

	# Global variables
	vibration_values = deque(maxlen=VIBRATION_BUFFER_SIZE)
	timer = time.time()
	
	vib_thread = threading.Thread(target = vibration_list)
	vib_thread.daemon = True
	vib_thread.start()
	
	data_thread = threading.Thread(target = collect_data)
	data_thread.daemon = True
	data_thread.start()
	
	interval = 10  
	internet_thread = threading.Thread(target=check_internet_periodically, args=(26, interval))
	internet_thread.daemon = True
	internet_thread.start()
	
	while True:
	    target, output = read_rpm()
	    my_server()
