import os
import sys
import time
import math
import json
import socket
import threading
import logging
import numpy as np
from datetime import datetime
from collections import deque

from config import SERVER_IP, SERVER_PORT
from config import IMU_PORT, IMU_BAUDRATE, IMU_UPDATERATE
from config import VIBRATION_BUFFER_SIZE

from witmotion import IMU
from panel_lamp import check
import sensor_temp
import sensor_rpm

class Server:
    def __init__(self):
        self.vibration_values = deque(maxlen=VIBRATION_BUFFER_SIZE)
        self.running = True
        self.imu = None

        self.relay_pin = 26
        check(self.relay_pin)

    def callback(self, msg):
        """
        Callback function for receiving vibration data from the IMU sensor.
        """
        self.imu.get_acceleration()

    def read_vib(self):
        """
        Read the radial acceleration value from the IMU sensor.
        """
        acc_radial = math.sqrt((self.imu.last_a[0] ** 2) + (self.imu.last_a[1] ** 2))
        return acc_radial

    def vibration_list(self):
        """
        Thread function to continuously read vibration data in a separate thread.
        """
        self.imu = IMU(IMU_PORT, IMU_BAUDRATE)
        self.imu.set_update_rate(IMU_UPDATERATE)

        while self.running:
            self.vibration_values.append(self.read_vib())
            time.sleep(0.005)

    def collect_data(self):
        """
        Collect data from various sensors and format it into a JSON string.
        """
        while self.running:
            temperature = sensor_temp.read_temp()
            rpm = np.random.uniform(2800, 2900)

            data = {
                "LHL01": {
                    "timestamp": datetime.now().isoformat("@", "seconds"),
                    "performance_log": {
                        "temperature": temperature,
                        "rpm": rpm,
                        "vibration": ",".join(map(str, self.vibration_values))
                    }
                }
            }

            data = json.dumps(data)
            return data

    def send_data_to_client(self, client_socket):
        """
        Send collected data to the connected client.
        """
        try:
            while True:
                msg_from_server = self.collect_data()

                client_socket.sendall(msg_from_server.encode('utf-8'))
                
                client_socket.settimeout(5)
                
                try:
                    acknowledgment = client_socket.recv(1024).decode('utf-8')
                    if acknowledgment != "ACK":
                        print("Failed to receive acknowledgment from client.")
                        break
                    
                except socket.timeout:
                    logging.warning('Timed out while waiting for acknowledgment from the client.')
                    break

                time.sleep(1)

        except Exception as e:
            logging.exception('An error occurred: {}'.format(str(e)))
        finally:
            client_socket.close()

    def my_server(self):
        """
        Main server function to accept client connections and send data to clients.
        """
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((SERVER_IP, SERVER_PORT))
        server_socket.listen(1)

        print('---')
        print('SERVER NOW IS UP')
        print('---')

        while True:
            try:
                client_socket, address = server_socket.accept()
                logging.info('Accepted connection from: {}'.format(address))

                data_thread = threading.Thread(target=self.send_data_to_client, args=(client_socket,))
                data_thread.start()
            except socket.timeout:
                logging.warning('Client connection timed out.')
                client_socket.close()
           
            except Exception as e:
                logging.exception('An error occurred: {}'.format(str(e)))
                break

        self.running = False
        server_socket.close()

if __name__ == '__main__':
    server = Server()
    vib_thread = threading.Thread(target=server.vibration_list)
    vib_thread.daemon = True
    vib_thread.start()

    data_thread = threading.Thread(target=server.collect_data)
    data_thread.daemon = True
    data_thread.start()

    server.my_server()

                
        
