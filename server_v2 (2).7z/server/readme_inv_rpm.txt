##########
'''INVERTER MODBUS SETTINGS CODE'''
##########

reading_offset = 40196
#40196 (40195+1) #P.195 

'''OTHERS'''
#44106 #H100A=Line speed target value (pg.187)
#44100 (44009+1) #H1003=Output frequency (pg.189)
#Start with output frequency with unit: 
#Output frequency = 0.01 Hz
#Output current = 0.1 A
#Output voltage = 1 V
