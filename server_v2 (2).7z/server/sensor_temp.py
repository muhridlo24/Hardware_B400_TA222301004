##########
'''TEMPERATURE SENSOR CODE'''
##########

import board
import busio
import digitalio
import RPi.GPIO as GPIO
import adafruit_max31865

def read_temp():
	GPIO.setmode(GPIO.BCM)
	
	spi = board.SPI()
	cs = digitalio.DigitalInOut(board.D1) 
	sensor = adafruit_max31865.MAX31865(spi, cs)
	temperature = sensor.temperature
	return temperature

