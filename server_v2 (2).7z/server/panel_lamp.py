import socket
import RPi.GPIO as GPIO
import sys
import time

def check_internet(pin_num):
    try:
        # Set up connection indicator pin
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(pin_num, GPIO.OUT)

        # Set on
        def on():
            GPIO.output(pin_num, GPIO.HIGH)
        
        # Set off
        def off():
            GPIO.output(pin_num, GPIO.LOW)

        # Initialize indicator state
        is_indicator_on = False

        while True:
            # Internet checker
            IPaddress = None
            try:
                IPaddress = socket.gethostbyname(socket.gethostname())
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(('8.8.8.8', 80))
                IPaddress = s.getsockname()[0]
                s.close()
                if not is_indicator_on:
                    print("----------")
                    print("Internet: " + IPaddress)
                    print("Indicator: ON")
                    on()
                    is_indicator_on = True
                    print("----------")
            except socket.error:
                if is_indicator_on:
                    print("----------")
                    print("Error: Failed to connect to the internet.")
                    print("Indicator: OFF")
                    off()
                    is_indicator_on = False
                    print("----------")
            except Exception as e:
                if is_indicator_on:
                    print("----------")
                    print("Error:", e)
                    print("Indicator: OFF")
                    off()
                    is_indicator_on = False
                    print("----------")
                
            time.sleep(10)  # Wait for 10 seconds before checking again

    except Exception as e:
        print("----------")
        print("Error:", e)
        print("----------")
        GPIO.cleanup()
        sys.exit(1)
    finally:
        GPIO.cleanup()
        sys.exit(0)
