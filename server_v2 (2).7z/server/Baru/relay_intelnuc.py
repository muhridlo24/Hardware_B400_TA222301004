import socket
import subprocess
import time 

# Define functions to turn relay on and off
def turn_relay_on():
    subprocess.run(["sudo", "hidusb-relay-cmd", "on", "1"])

def turn_relay_off():
    subprocess.run(["sudo", "hidusb-relay-cmd", "off", "1"])

# Continuously check internet connection and control relay
while True:
    IPaddress=socket.gethostbyname(socket.gethostname())
    if IPaddress=="127.0.0.1":
        print("No internet " + IPaddress)
        turn_relay_off()
    else:
        print("Internet " + IPaddress)
        turn_relay_on()
    time.sleep(5)  # Wait for 10 seconds before checking again

