import RPi.GPIO as io

io.setmode(io.BCM)
io.setup(20,io.IN,pull_up_down=io.PUD_DOWN)
io.setup(21,io.IN,pull_up_down=io.PUD_DOWN)
io.setup(16,io.IN,pull_up_down=io.PUD_DOWN)

while 1 :
	print(io.input(16),io.input(21),io.input(20))