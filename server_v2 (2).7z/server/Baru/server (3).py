#LIBRARY
import socket
import time
import board
import busio
import digitalio
import adafruit_max31865
import math
from datetime import datetime
import RPi.GPIO as GPIO
import numpy as np
import json
from witmotion import IMU
import random
import sys
import select
import threading

last_send_time = 0.0

# set up connection indicator pin
GPIO.setmode(GPIO.BCM)
GPIO.setup(26, GPIO.OUT)

def set_connection(state):#CEK KONEKSI
    if state == 'on':
        GPIO.output(26, GPIO.LOW)
    elif state == 'off':
        GPIO.output(26, GPIO.HIGH)

def check_connection():#FUNSI UTAMA CEK KONEKSI
    try:
        output = subprocess.check_output(["ping", "-c", "1", "8.8.8.8"])
        set_connection(on) 
    except subprocess.CalledProcessError:
        set_connection(off)  

#2. FUNGSI AMBIL DATA SENSOR   
def read_temperature():#DATA SENSOR TEMPERATUR
    temperature = sensor.temperature
    return temperature 
    
def callback(msg):#DATA SENSOR VIBRASI
    spi = busio.SPI(board.SCK, MOSI=board.MOSI, MISO=board.MISO)
    cs = digitalio.DigitalInOut(board.D5)
    sensor = adafruit_max31865.MAX31865(spi, cs)
    temperature = sensor.temperature
    return temperature

def append_acc(list_acc, imu, duration):#APPEND DATA SENSOR DI LIST
    start_time = time.time()

    while time.time() - start_time < duration:
        vibration = imu.subscribe(callback)
        if vibration is not None:
            x_acc = vibration[0]
            list_acc.append(x_acc)
        else:
            print("No acceleration data received")

def collect_data(temperature, list_acc):#SATUKAN DATA
    data = {
        "LHL01": {
            "timestamp": datetime.now().isoformat("@", "seconds"),
            "performance_log": {
                "temperature": temperature,
                "rpm": np.random.uniform(2800, 2900),
                "vibration": ",".join(map(str, list_acc))
            }
        }
    }
    data = json.dumps(data)
    return data
   
#3. FUNSI SERVER    
def my_server():#ATUR SERVER MENGIRIM 
    global temperature, list_acc
    bufferSize = 1024
    msgFromServer = collect_data(temperature, list_acc)

    # Port and Raspi IP
    ServerPort = 3333
    ServerIP = "192.168.43.96"

    # Encode msg
    bytesToSend = msgFromServer.encode('utf-8')
    RPIsocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    RPIsocket.bind((ServerIP, ServerPort))

    # Server on indicator
    print('Server is up')

    ready = select.select([RPIsocket], [], [], 1.0)

    if ready[0]:
        # Receive and decode msg
        message, address = RPIsocket.recvfrom(bufferSize)
        message = message.decode('utf-8')
        print(message)

        print('Client Address', address[0])
        RPIsocket.sendto(bytesToSend, address)

#FUNGSI MAIN 
if __name__ == '__main__': #first call

    #declare variables for temperature and vibration sensors
    global temperature, list_acc, RPIsocket
    temperature = None
    list_acc = []
    imu = IMU("/dev/ttySC1",9600)
    imu.set_baudrate(9600)
    imu.set_update_rate(200)
    duration = 1.0 #1 second
    
    # Port and Raspi IP
    ServerPort = 3333
    ServerIP = "192.168.43.96"
    RPIsocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    #initialize last_send_time
    last_send_time = time.time()

    #set up server
    server_thread = threading.Thread(target=my_server)
    server_thread.daemon = True
    server_thread.start()

    while True: #for looping continously
        current_time = time.time()
        if current_time - last_send_time >= 1.0:
            try:
                msgFromServer = collect_data(read_temperature(), list_acc)
                bytesToSend = msgFromServer.encode('utf-8')
                RPIsocket.sendto(bytesToSend, (ServerIP, ServerPort))
            except Exception as e:
                # Log the error and take appropriate action (e.g. notify user, shut down system, etc.)
                print(f"An error occurred: {e}")
                set_connection('off')
            else:
                list_acc.clear()
                last_send_time = current_time
        else:
            append_acc(list_acc, imu, duration)
        time.sleep(0.1)
