import time
print("Hello")

time.sleep(1)
