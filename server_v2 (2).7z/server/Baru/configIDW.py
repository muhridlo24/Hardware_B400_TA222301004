line = 'TUP08'
ip_api = 'http://10.3.5.102:3000/'
dns_api = 'https://mesapi.pti-cosmetics.com/'
env = 'production'
