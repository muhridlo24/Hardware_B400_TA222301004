import time
import threading

# Define the function to calculate the sum of a list of numbers
def calculate_sum(numbers):
    result = 0
    for number in numbers:
        result += number
    return result

# Define the function to calculate the sum of a list of numbers using multiple threads
def calculate_sum_threaded(numbers, num_threads):
    results = [0] * num_threads

    # Define the function to calculate the sum of a subset of the list
    def calculate_subset_sum(subset, result_index):
        results[result_index] = calculate_sum(subset)

    # Divide the list into subsets and create a thread for each subset
    subsets = []
    subset_size = len(numbers) // num_threads
    for i in range(num_threads):
        start_index = i * subset_size
        end_index = (i+1) * subset_size if i != num_threads-1 else len(numbers)
        subset = numbers[start_index:end_index]
        subsets.append(subset)
        thread = threading.Thread(target=calculate_subset_sum, args=(subset, i))
        thread.start()

    # Wait for all threads to finish
    for thread in threading.enumerate():
        if thread != threading.current_thread():
            thread.join()

    # Combine the results from each thread
    result = 0
    for thread_result in results:
        result += thread_result
    return result

# Define the list of numbers to calculate the sum of
numbers = list(range(1, 10000001))

# Calculate the sum using a single thread and measure the time it takes
start_time = time.time()
result_single_thread = calculate_sum(numbers)
end_time = time.time()
print(f"Single thread result: {result_single_thread}")
print(f"Single thread time: {end_time - start_time}")

# Calculate the sum using multiple threads and measure the time it takes
start_time = time.time()
result_multi_thread = calculate_sum_threaded(numbers, 4)
end_time = time.time()
print(f"Multi-thread result: {result_multi_thread}")
print(f"Multi-thread time: {end_time - start_time}")
