from witmotion import IMU
import time
import math
import logging
from collections import deque

#logging.basicConfig(level=logging.DEBUG)

start_time = time.monotonic()
'''belum fail safe jika data kosong dan jika wifi mati'''
VIBRATION_BUFFER_SIZE = 200

# Global variables
vibration_values = deque(maxlen=VIBRATION_BUFFER_SIZE) 

def callback(msg):
	global start_time
	acc = imu.get_acceleration()
	acc_radial = math.sqrt(((acc[0]**2) + (acc[1]**2)))
	# elapsed_time = time.monotonic() - start_time
	# if elapsed_time >= 1/200:
		# if prev != acc_radial:
	vibration_values.append(acc_radial)
	if time.time()-start_time >= 1.0: 
		print(vibration_values)
		vibration_values.clear()
		timer = time.time()
	
imu = IMU("/dev/ttySC1", 115200)
imu.set_update_rate(200)
#imu.set_default_configuration()
imu.subscribe(callback)
