from pymodbus.client import ModbusSerialClient as ModbusClient
from pymodbus.exceptions import ModbusIOException, ConnectionException
import time

client = ModbusClient(method='rtu', port='/dev/ttySC0', stopbits=1, bytesize=8, parity='E', baudrate=9600, timeout=0.3)

# Define the address to read
address = 194
count = 4
unit = 0x01

# Loop until a response is received
while True:
    try:
        # Send the request to read the registers
        print(f'Sending request for registers: address={address}, count={count}, unit={unit}', end='')
        response = client.read_holding_registers(address=address, count=count, unit=unit)
        
        # Check if the response is valid
        if isinstance(response, ModbusIOException):
            print(f' Error reading registers: {response}')
        else:
            print(f' Registers: {response.registers}')
            break  # Exit the loop if a valid response is received
        
    except ModbusIOException as e:
        print(f' Modbus exception: {e}')
        
    except ConnectionException:
        print(f' Modbus connection error')
    
    # Wait a bit before sending the next request
    time.sleep(1)
