
#UPDATE ADD CATCH ERROR
##########################################################################################
#
# LIBRARY
#
##########################################################################################
from pickle import FALSE
from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
from time import sleep
import RPi.GPIO as io
from threading import Thread
import time
import json
import subprocess
import shlex
import requests
import urllib2
from datetime import datetime
import urlparse
import locale
import os, time
import configIDW

threshold = 9
env = configIDW.env
##########################################################################################

##########################################################################################
#
# SETUP
#
##########################################################################################

#Setting : GPIO Raspberry
io.setmode(io.BCM)          # Akses io menggunakan nama pin standar(GPIO 21)
io.setup(20,io.IN, pull_up_down=io.PUD_DOWN)          # Membuat GPIO 21 sebagai input
io.setup(21,io.IN, pull_up_down=io.PUD_DOWN)
io.setup(16,io.IN, pull_up_down=io.PUD_DOWN)
print ("Starting....") # print sesuatu
print (" Press Ctrl+C to quit")   # print sesuatu
# Setting Socket
PORT_NUMBER = 6900

# API Endpoint
if (env == 'production') :
    url = "http://10.3.5.102:3000/flow_input_snfg_wo" #POST response to activate the counter in server
else :
    url = "http://10.3.5.102:3333/flow_input_snfg_wo" #POST response to activate the counter in server

headers = {
    'content-type': "application/json",
    'cache-control': "no-cache",
    'postman-token': "964aef80-13fe-1d10-5309-96345ebb4732"
}
##########################################################################################

##########################################################################################
#
# VARIABLE
#
##########################################################################################

# Variabel for counting
a = 0
b = 0
c = 0
data = 0
tag = True
tagLess = True
tagOver = True
first = False
json_array = ""
isError = False
lastCounter = 0
counter = 0
offlineCounter = 0
counter_karbox = 0
counter_innerbox = 0
json_body = ""
json_body2 = ""

operator = ""
operator_innerbox = ""
item_name = ""
quantity = 0
no_batch = ""
exp_date = ""
snfg_id = 0
koitem_fg = ""
kode_odoo = ""
snfg = ""
no_smb = ""
warna = ""
barcode = ""
na_number = ""
fg_name_odoo = ""
nama_line = ""
qty_innerbox = 0
is_innerbox = 0
isPrint = False
once = True
forceInsert = False
tareOn = False
innerCounter = 0
karboxCounter = 0
batas = 0
flag = 1
is_counter = 0
datetime_stop = ""
isNew = True
doneTare = 0
arrOffline = []
formatDate = '%Y-%m-%d %H:%M:%S'
test_input = ""
last_timestamp = ""
printKarbox = False


##########################################################################################

##########################################################################################
#
# FUNCTION DEFINITION
#
##########################################################################################
class weighingPrintingOnline:
    def __init__(self):
        self._running = True

    def terminate(self):
        self._running = False

    def run(self):
        global a
        global b
        global c
        global data
        global tag
        global tagLess
        global tagOver
        global threshold
        global json_array
        global koitem_fg
        global operator
        global operator_innerbox
        global exp_date
        global item_name
        global kode_odoo
        global snfg
        global snfg_id
        global no_smb
        global no_batch
        global quantity
        global json_body
        global offlineCounter
        global isError
        global lastCounter
        global first
        global counter
        global counter_karbox
        global counter_innerbox
        global isPrint
        global once
        global forceInsert
        global tareOn
        global warna
        global barcode
        global na_number
        global fg_name_odoo
        global qty_innerbox
        global is_innerbox
        global nama_line
        global innerCounter
        global karboxCounter
        global batas
        global flag
        global json_body2
        global is_counter
        global datetime_stop
        global isNew
        global doneTare
        global arrOffline
        global formatDate
        global adjust_vertical
        global adjust_vertical_inner
        global test_input
        global last_timestamp
        global last_timestamp_
        global printKarbox

        while self._running:
            time.sleep(0.4) # 200ms delay

            if (io.input(16) == 0) :
                a+=1
                b=0
                c=0
            elif (io.input(21) == 0) :
                b+=1
                a=0
                c=0
            elif (io.input(20) == 0) :
                c+=1
                a=0
                b=0
            else :
                a=0
                b=0
                c=0
                tag = True
                tagLess = True
                tagOver = True

            # AMBIL DATA PERTAMA KALI ATAU KETIKA TAB DI REFRESH
            if (isNew):
                try :
                    # contents = urllib2.urlopen("http://10.3.181.193:3080/log/write?message=getData").read()
                    contents = urllib2.urlopen(configIDW.ip_api+"api_weigher_snfg?nama_line=plfts."+configIDW.line).read()
                    json_array = json.loads(contents)

                    print 'BERHASIL GET DATA'

                    isError = False
                    first = True
                    start_time = datetime.now();
                    lastCounter = json_array[0]['cur_seq']
                    last_karboxCounter = json_array[0]['counter_karbox']
                    last_innerCounter = json_array[0]['counter_innerbox']
                    counter = lastCounter
                    operator = json_array[0]['nama_operator']
                    operator_innerbox = json_array[0]['nama_operator_innerbox']
                    last_timestamp = json_array[0]['current_timestamp']
                    item_name = json_array[0]['nama_fg']
                    quantity = json_array[0]['koli']
                    no_batch = json_array[0]['nobatch']
                    exp_date = json_array[0]['exp_date']
                    kode_odoo = json_array[0]['odoo_code']
                    snfg_id = json_array[0]['id']
                    koitem_fg = json_array[0]['koitem_fg']
                    snfg = json_array[0]['snfg']
                    no_smb = json_array[0]['nosmb']
                    warna = json_array[0]['warna']
                    barcode = json_array[0]['barcode']
                    na_number = json_array[0]['na_number']
                    fg_name_odoo = json_array[0]['fg_name_odoo']
                    qty_innerbox = json_array[0]['qty_innerbox']
                    is_innerbox = json_array[0]['is_innerbox']
                    nama_line = json_array[0]['nama_line']
                    is_counter = json_array[0]['is_counter']
                    datetime_stop = json_array[0]['datetime_stop']
                    adjust_vertical = int(json_array[0]['adjust_vertical'])
                    adjust_vertical_inner = int(json_array[0]['adjust_vertical_inner'])
                    
                    if "/BS" in snfg :
                        print 'is Bulk Sisa'
                        adjust_vertical_inner = int(25)

                    if ((json_array[0]['is_print'] == 1) and (not json_array[0]['datetime_stop'])  ) :
                        isPrint = True
                    else :
                        isPrint = False

                    if ((operator != '') and ((is_innerbox != 1) or (is_innerbox == 1 and operator_innerbox != ''))) :
                        opChoosed = True
                    else :
                        opChoosed = False

                    if (is_counter == 1 and is_innerbox == 1) : # is_counter DARI TABEL weigher_fg_map_device
                        batas = quantity / qty_innerbox

                    if (json_array[0]['done_tare'] == 1)  :
                        doneTare = True
                    else :
                        doneTare = False


                    isNew = False
                    offlineCounter = 0


                    counter = lastCounter

                    if (is_innerbox == 1):
                        if (last_innerCounter >= batas) :
                            innerCounter = 1
                            karboxCounter = last_karboxCounter + 1

                        else :
                            innerCounter = last_innerCounter + 1
                            karboxCounter = last_karboxCounter
                    else :
                        innerCounter = 1
                        karboxCounter = counter

                    forceInsert = True

                except:
                    print 'GAGAL GET DATA'

                    isError = True
                    first = False


            # KONDISI KETIKA TIMBANGAN MERAH / OVER
            if (a>threshold and tagOver): # DELAY AGAR MENUNGGU TIMBANGAN STABIL. (a x 100ms)
                tagOver = False
                merah_time = datetime.now()

                print 'KONDISI MERAH'

                if (first):
                    pass

                try :
                    if not datetime_stop :
                        if (not tareOn and opChoosed) :
                            # KIRIM DATA STATUS TIMBANG MERAH KE SERVER, AGAR MUNCUL DI TABLET
                            if (is_innerbox == 1) :
                                operator_ = operator_innerbox
                            else :
                                operator_ = operator

                            # payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(operator_)+"\",\"write_time\":\""+time.strftime(formatDate)+"\",\"nourut\":"+str(counter)+",\"status\":\"over\"}"
                            payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(operator_)+"\",\"nourut\":"+str(counter)+",\"status\":\"over\",\"counter_innerbox\":"+str(innerCounter)+",\"counter_karbox\":"+str(karboxCounter)+"}"
                            response = requests.request("POST", url, data=payload, headers=headers)
                            print "BERHASIL SEND DATA MERAH"

                            # offlineCounter += 1


                        #Change isError jika ada perubahan state dari offline menjadi online dan forceInsert data arrOffline
                        if (isError):
                            isError = False
                            forceInsert = True

                except :
                    # KETIKA OFFLINE (TRY CONNECT GAGAL), MENYIMPAN DATA TERAKHIR KE VARIABEL
                    print ("Offline Mode")
                    isError = True

                    duration = merah_time - start_time
                    last_timestamp_ = datetime.strptime(last_timestamp,formatDate)
                    new_time = last_timestamp_ + duration
                    new_time_str = new_time.strftime(formatDate)

                    # KETIKA PROGRAM OFFLINE, PERLU MENYIMPAN TIMESTAMP DI LOCAL
                    #Add timestamp over to an array
                    arrOffline.append({'timestamp':new_time.strftime(formatDate),'counter':counter,'status':'over','counter_innerbox':str(innerCounter),'counter_karbox':str(karboxCounter)})

                    offlineCounter += 1

            # KONDISI KETIKA TIMBANGAN HIJAU
            if (b>3 and tag): # DELAY AGAR MENUNGGU TIMBANGAN STABIL. (3 x 100ms)
                tag = False
                hijau_time = datetime.now();

                print 'KONDISI HIJAU'

                # FLAG PRINT COUNTER KETIKA OFFLINE
                if (first):
                    pass

                try :
                    # KETIKA PAKAI COUNTER, MAKA BACA BATAS COUNTER
                    if (is_counter == 1 and is_innerbox == 1) : # is_counter DARI TABEL weigher_fg_map_device
                        batas = quantity / qty_innerbox


                    # LOGIC UNTUK PRINT
                    #
                    # KETIKA OPERATOR SUDAH MELAKUKAN TARE DAN KONDISI TARE OFF -> BOLEH PRINT (TOMBOL DI TABLET)
                    if not datetime_stop :
                        print "lolos datetime_stop"
                        if (not tareOn and opChoosed) :
                            print "lolos tareOn"
                            # KETIKA BOLEH PRINT (is_print dapat dari jenis proses nya), FILLING HARUSNYA GA PRINT
                            if (isPrint == 1) :
                                print "lolos is print"

                                # JIKA ITEM TIDAK PAKAI INNERBOX
                                if (is_innerbox != 1) :
                                    print "lolos innerbox"
                                    # JIKA ITEM PAKAI KARBOX MALAYSIA, TEMPLATE NYA zpl_malaysia
                                    if "MY-" in koitem_fg :
                                        # TEMPLATE LABEL MALAYSIA
                                        json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                                        "^FX Line Vertical\r\n^FO330,145\r\n^GB0,110,1^FS\r\n\r\n^FX Line Vertical\r\n^FO400,255\r\n^GB0,105,1^FS\r\n\r\n^FX Line Vertical\r\n^FO220,255\r\n^GB0,60,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,145\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,195\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,255\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,315\r\n^GB350,0,1^FS\r\n\r\n"
                                                        "^FX QR code\r\n^FT50,"+str(140+adjust_vertical)+",0\r\n^BQN,2,3,Q,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n\r\n"
                                                        "^FX ODOO CODE human readable\r\n^FO175,25\r\n^ADN,16\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                                        "^FX Item name human readable\r\n^CI28\r\n^FO175,50\r\n^ARN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB385,3,,\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                                        "^FX SNFG Title\r\n^FO50,150\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO50,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB280,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                                        "^FX SMB Title\r\n^FO340,150\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO340,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                                        "^FX Lakban human readable\r\n^FO50,215\r\n^AQN15,15\r\n\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB265,1,,C ^FD"+warna+"^FS\r\n\r\n"
                                                        "^FX Exp Date Title\r\n^FO340,200\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO340,222\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                                        "^FX Batch Title\r\n^FO50,265\r\n^ABN5,5\r\n^FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO50,282\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                                        "^FX Operator\r\n^FO225,260\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO225,285\r\n^AQN15,15\r\n^FDSN : "+str(counter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                                        "^FX Qty per box Title\r\n^FO410,266\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO410,285\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                                        "^FX EAN-13\r\n^FO150,321^BY2\r\n^BEN,20,Y,N\r\n^FD"+str(barcode)+"^FS\r\n\r\n"
                                                        "^FX inline Title ^FO450,340 ^AAN15,15 ^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                                    else :
                                        print "lolos non malaysia"

                                        # TEMPLATE LABEL KARBOX NON-MALAYSIA
                                        # json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                        #    "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                                        #    "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                                        #    "^FX SKU human readable\r\n^FO230,20\r\n^ADN,16\r\n^FH\\^FDSKU: "+koitem_fg+"^FS\r\n\r\n"
                                        #    "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^ARN,16 ^FB360,3,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                        #    "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                        #    "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                        #    "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                                        #    "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                        #    "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                        #    "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(counter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                        #    "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                        #    "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                                        #    "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")

                                        if len(fg_name_odoo) > 70 :
                                            # TEMPLATE KARBOX NON-MALAYSIA
                                            json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                                "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                                                "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                                                "^FX ODOO CODE human readable\r\n^FO230,20\r\n^A0N23,23,B:CYRI_UB.FNT\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                                "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^A0N,23 ^FB340,4,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                                "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                                "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                                "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                                                "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                                "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                                "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(counter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                                "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                                "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                                                "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                                        else :
                                            # TEMPLATE KARBOX NON-MALAYSIA
                                            json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                                "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                                                "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                                                "^FX ODOO CODE human readable\r\n^FO230,20\r\n^A0N23,23,B:CYRI_UB.FNT\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                                "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^A0N,26 ^FB340,3,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                                "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                                "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                                "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                                                "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                                "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                                "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(counter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                                "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                                "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                                                "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")



                                # JIKA ITEM PAKAI INNERBOX, TEMPLATE NYA zpl
                                else :
                                    # CODE UNTUK PRINT INNERBOX
                                    json_body = (
                                        "^FX Begin setup\n^XA\n~TA120\n~JSN\n^LT0\n^MNW\n^MTT\n^PON\n^PMN\n^LH0,0\n^JMA\n^PR4,4\n~SD25\n^JUS\n^LRN\n^CI0\n^MD0\n^XZ\n^FX End setup\n\n"
                                        "^FX Begin label format\n^XA\n^MMT\n^LL0254\n^PW629\n^LS0\n\n^FX Box-line Vertical\n^FO55,25\n^GB0,330,2^FS\n\n^FX Box-line Vertical\n^FO580,25\n^GB0,332,2^FS\n\n^FX Box-line Horizontal\n^FO55,25\n^GB525,0,2^FS\n\n^FX Box-line Horizontal\n^FO55,355\n^GB526,0,2^FS\n\n^FX Line Vertical\n^FO120,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO200,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO250,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO297,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO400,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO450,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO510,185\n^GB0,170,1^FS\n\n^FX Line Horizontal\n^FO450,185\n^GB130,0,1^FS\n\n"
                                        "^FX QR code\n^FT70,"+str(355+adjust_vertical_inner)+",0\n^BQN,2,5,H,7\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(qty_innerbox)+"|E:"+str(exp_date)+"^FS\n\n"
                                        "^FX Batch readable\n^FO80,30\n^ABB25,25,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB130,1,,C\n^FD"+str(no_batch)+"^FS\n\n"
                                        "^FX Operator readable\n^FO135,20\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDOP:"+str(operator_innerbox)+"^FS\n \n"
                                        "^FX SN Title readable\n^FO165,120\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB40,1,,L\n^FDSN:^FS\n \n^FX SN Value readable\n^FO165,30\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB100,2,,L\n^FD"+str(counter)+"_"+str(snfg_id)+"^FS\n\n"
                                        "^FX Line readable\n^FO215,20\n^A0B20,20,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDLINE : "+str(nama_line)+"^FS\n\n"
                                        "^FX Odoo Code readable\r\n^FO265,155\r\n^A0B23,23,B:CYRI_UB.FNT\r\n^FX Field block 500 dots wide, 3 lines max\r\n^FB240,2,,R\r\n^FDODOO CODE : "+kode_odoo+"^FS\r\n\r\n"
                                        "^FX Item Name Label\n^FO303,267\n^ABB,15,10\n^FDItem Name^FS\n\n^FX Item name human readable\n^CI28\n^FO325,33\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB315,3,,L\n^FD"+fg_name_odoo+"^FS\n\n"
                                        "^FX SNFG Label\n^FO405,310\n^ABB,15,10\n^FDSNFG^FS\n\n^FX SNFG human readable\n^FO425,40\n^ADB,16\n^FX Field block 500 dots wide, 3 lines max\n^FB300,3,,L\n^FD"+snfg+"^FS\n\n"
                                        "^FX NA Number Label\n^FO455,265\n^ABB,15,10\n^FDNA Number^FS\n\n^FX NA Number human readable\n^FO480,182\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB160,1,,L\n^FD"+str(na_number)+"^FS\n\n"
                                        "^FX Exp Date Label\n^FO515,247\n^ABB,15,10\n^FDExpiry Date^FS\n\n^FX Exp Date readable\n^FO540,190\n^AQB35,35,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB165,1,,C\n^FD"+str(exp_date)+"^FS\n\n"
                                        "^FX Qty er innerbox Label\n^FO455,35\n^ABB,15,10\n^FDQty per innerbox^FS\n\n^FX Qty per innerbox readable\n^FO485,30\n^ABB65,65,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB150,1,,C\n^FD^FD"+str(qty_innerbox)+"^FS\n\n"
                                        "^FX inline Title\n^FO565,90\n^AAB5,5\n^FDinline^FS\n\n"
                                        "^FX Print quantity\n^PQ1,0,1,Y\n\n"
                                        "^FX End label format\n^XZ\n"
                                    )

                                args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                                lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                                lpr.stdin.write(json_body.encode("utf-8"))
                                lpr.stdin.close()

                                # CODE UNTUK PRINT JIKA LINE NYA PAKAI COUNTER
                                if (is_counter == 1 and is_innerbox == 1) :
                                    print "lolos counter"
                                    # innerCounter += 1 # ADD COUNTER (khusus mode counter)
                                    if (innerCounter >= batas) :
                                        print "print karbox"

                                        if "MY-" in koitem_fg :
                                            json_body2 = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                                    "^FX Line Vertical\r\n^FO330,145\r\n^GB0,110,1^FS\r\n\r\n^FX Line Vertical\r\n^FO400,255\r\n^GB0,105,1^FS\r\n\r\n^FX Line Vertical\r\n^FO220,255\r\n^GB0,60,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,145\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,195\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,255\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,315\r\n^GB350,0,1^FS\r\n\r\n"
                                                    "^FX QR code\r\n^FT50,"+str(140+adjust_vertical)+",0\r\n^BQN,2,3,Q,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n\r\n"
                                                    "^FX ODOO CODE human readable\r\n^FO175,25\r\n^ADN,16\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                                    "^FX Item name human readable\r\n^CI28\r\n^FO175,50\r\n^ARN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB385,3,,\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                                    "^FX SNFG Title\r\n^FO50,150\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO50,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB280,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                                    "^FX SMB Title\r\n^FO340,150\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO340,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                                    "^FX Lakban human readable\r\n^FO50,215\r\n^AQN15,15\r\n\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB265,1,,C ^FD"+warna+"^FS\r\n\r\n"
                                                    "^FX Exp Date Title\r\n^FO340,200\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO340,222\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                                    "^FX Batch Title\r\n^FO50,265\r\n^ABN5,5\r\n^FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO50,282\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                                    "^FX Operator\r\n^FO225,260\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO225,285\r\n^AQN15,15\r\n^FDSN : "+str(karboxCounter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                                    "^FX Qty per box Title\r\n^FO410,266\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO410,285\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                                    "^FX EAN-13\r\n^FO150,321^BY2\r\n^BEN,20,Y,N\r\n^FD"+str(barcode)+"^FS\r\n\r\n"
                                                    "^FX inline Title ^FO450,340 ^AAN15,15 ^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                                        else :
                                            if len(fg_name_odoo) > 70 :
                                                # TEMPLATE KARBOX NON-MALAYSIA
                                                json_body2 = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                                    "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                                                    "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                                                    "^FX ODOO CODE human readable\r\n^FO230,20\r\n^A0N23,23,B:CYRI_UB.FNT\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                                    "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^A0N,23 ^FB340,4,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                                    "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                                    "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                                    "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                                                    "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                                    "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                                    "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(karboxCounter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                                    "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                                    "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                                                    "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                                            else :
                                                # TEMPLATE KARBOX NON-MALAYSIA
                                                json_body2 = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                                    "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                                                    "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                                                    "^FX ODOO CODE human readable\r\n^FO230,20\r\n^A0N23,23,B:CYRI_UB.FNT\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                                    "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^A0N,26 ^FB340,3,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                                    "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                                    "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                                    "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                                                    "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                                    "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                                    "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(karboxCounter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                                    "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                                    "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                                                    "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")


                                        args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                                        lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                                        lpr.stdin.write(json_body2.encode("utf-8"))
                                        lpr.stdin.close()

                                        printKarbox = True

                            # KIRIM DATA STATUS TIMBANG HIJAU KE SERVER, AGAR MUNCUL DI TABLET
                            if (is_innerbox == 1) :
                                operator_ = operator_innerbox
                            else :
                                operator_ = operator

                            payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(operator_)+"\",\"nourut\":"+str(counter)+",\"status\":\"pass\",\"counter_innerbox\":"+str(innerCounter)+",\"counter_karbox\":"+str(karboxCounter)+"}"
                            response = requests.request("POST", url, data=payload, headers=headers)

                            print "BERHASIL SEND DATA HIJAU"

                            # offlineCounter += 1

                            if (printKarbox):
                                innerCounter = 0
                                karboxCounter += 1
                                printKarbox = False

                            if (is_innerbox == 1) :
                                innerCounter += 1
                            else :
                                karboxCounter += 1

                            counter += 1


                        #Change isError jika ada perubahan state dari offline menjadi online dan forceInsert data arrOffline
                        if (isError):
                            isError = False
                            forceInsert = True


                except :
                    # KETIKA OFFLINE (TRY PUSH GAGAL), MENYIMPAN DATA TIMBANG TERAKHIR KE ARRAY
                    print ("Offline Mode")
                    isError = True

                    duration = hijau_time - start_time
                    last_timestamp_ = datetime.strptime(last_timestamp,formatDate)
                    new_time = last_timestamp_ + duration
                    new_time_str = new_time.strftime(formatDate)

                    #Add timestamp pass to an array
                    arrOffline.append({'timestamp':new_time.strftime(formatDate),'counter':counter,'status':'pass','counter_innerbox':str(innerCounter),'counter_karbox':str(karboxCounter)})

                    if (printKarbox):
                        innerCounter = 0
                        karboxCounter += 1
                        printKarbox = False

                    if (is_innerbox == 1) :
                        innerCounter += 1
                    else :
                        karboxCounter += 1

                    counter += 1
                    offlineCounter += 1


            # KONDISI KETIKA TIMBANGAN KUNING
            if (c>threshold and tagLess): # DELAY AGAR MENUNGGU TIMBANGAN STABIL. (c x 100ms)
                tagLess = False
                kuning_time = datetime.now()

                print 'KONDISI KUNING'

                # FLAG PRINT COUNTER KETIKA OFFLINE
                if (first):
                    pass

                try :
                    # KIRIM DATA STATUS TIMBANG MERAH KE SERVER, AGAR MUNCUL DI TABLET
                    if not datetime_stop :
                        if (not tareOn and opChoosed) :
                            if (is_innerbox == 1) :
                                operator_ = operator_innerbox
                            else :
                                operator_ = operator

                            # payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(operator_)+"\",\"nourut\":"+str(counter)+",\"status\":\"less\"}"
                            payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(operator_)+"\",\"nourut\":"+str(counter)+",\"status\":\"less\",\"counter_innerbox\":"+str(innerCounter)+",\"counter_karbox\":"+str(karboxCounter)+"}"
                            response = requests.request("POST", url, data=payload, headers=headers)

                        #Change isError jika ada perubahan state dari offline menjadi online dan forceInsert data arrOffline
                        if (isError):
                            isError = False
                            forceInsert = True
                except :
                    # KETIKA OFFLINE (TRY CONNECT GAGAL), MENYIMPAN DATA TERAKHIR KE VARIABEL
                    print ("Offline Mode")

                    duration = kuning_time - start_time
                    last_timestamp_ = datetime.strptime(last_timestamp,formatDate)
                    new_time = last_timestamp_ + duration
                    new_time_str = new_time.strftime(formatDate)

                    isError = True

                    #Add timestamp over to an array
                    arrOffline.append({'timestamp':new_time.strftime(formatDate),'counter':counter,'status':'less','counter_innerbox':str(innerCounter),'counter_karbox':str(karboxCounter)})

                    offlineCounter += 1

            # SCRIPT UNTUK CEK APAKAH SUDAH BISA KONEK KE SERVER
            # CEK SETIAP KELIPATAN 5. KETIKA PRINT LABEL 5X DAN KELIPATANNYA
            #if (offlineCounter % 24 == 0 and offlineCounter > 0 and once): # 5 menit -> 10
            if ( (len(arrOffline) % 5 == 0 and len(arrOffline) > 0) or forceInsert): # 5 menit -> 10
                print "Masuk forceInsert"

                try :
                    contents = urllib2.urlopen(configIDW.ip_api+"api_weigher_snfg?nama_line=plfts."+configIDW.line).read()

                    # KIRIM DATA LOG PENIMBANGAN, HANYA YANG HIJAU
                    for x in range (len(arrOffline)):
                        if (is_innerbox == 1) :
                            operator_ = operator_innerbox
                        else :
                            operator_ = operator


                        payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(operator_)+"\",\"nourut\":"+str(arrOffline[x]['counter'])+",\"status\":\""+str(arrOffline[x]['status'])+"\",\"write_time\":\""+str(arrOffline[x]['timestamp'])+"\",\"counter_innerbox\":\""+str(arrOffline[x]['counter_innerbox'])+"\",\"counter_karbox\":\""+str(arrOffline[x]['counter_karbox'])+"\"}"

                        response = requests.request("POST", url, data=payload, headers=headers)

                    isError = False
                    forceInsert = False
                    offlineCounter = 0
                    arrOffline = []
                    print ("Back to Online Mode")
                    once = True
                except :
                    isError = True
                    # once = False
                    forceInsert = False


# API PER CLIENT, KEPERLUAN UNTUK MENERIMA PERINTAH DARI TABLET, ATAU CEK STATUS
class apiHandler(BaseHTTPRequestHandler):
    #Handler for the GET requests
    def do_GET(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Content-type','application/json')
        self.end_headers()
        global innerCounter
        global tareOn
        global isNew
        global forceInsert

    # POST JSON
        if "?" in self.path:
            for key,value in dict(urlparse.parse_qsl(self.path.split("?")[1], True)).items():
                # API UNTUK PRINT LABEL TEST
                if (key=="test"):
                    command_line = "lpr -P Zebra_Technologies_ZTC_GT800_ -o raw /home/pi/test.zpl"
                    args = shlex.split(command_line)
                    subprocess.call(args)
                    subprocess.call(args)
                    args = shlex.split("lpstat -p Zebra_Technologies_ZTC_GT800_")
                    output = subprocess.Popen( args, stdout=subprocess.PIPE ).communicate()[0]
                    if (len(output.split()) > 14):
                        serialized = json.dumps({ "test":0 }, sort_keys=True, indent=3)
                        self.wfile.write(serialized)
                    else:
                        serialized = json.dumps({ "test":1 }, sort_keys=True, indent=3)
                        self.wfile.write(serialized)

                # API UNTUK PRINT LABEL TERAKHIR (CONTOH : KETIKA MENGAMBIL LABEL SOBEK, MAKA PERLU PRINT ULANG YANG TERAKHIR)
                if (key=="last_innerbox"):
                    counter_last = counter - 1

                    # CODE UNTUK PRINT INNERBOX
                    json_body = (
                        "^FX Begin setup\n^XA\n~TA120\n~JSN\n^LT0\n^MNW\n^MTT\n^PON\n^PMN\n^LH0,0\n^JMA\n^PR4,4\n~SD25\n^JUS\n^LRN\n^CI0\n^MD0\n^XZ\n^FX End setup\n\n"
                        "^FX Begin label format\n^XA\n^MMT\n^LL0254\n^PW629\n^LS0\n\n^FX Box-line Vertical\n^FO55,25\n^GB0,330,2^FS\n\n^FX Box-line Vertical\n^FO580,25\n^GB0,332,2^FS\n\n^FX Box-line Horizontal\n^FO55,25\n^GB525,0,2^FS\n\n^FX Box-line Horizontal\n^FO55,355\n^GB526,0,2^FS\n\n^FX Line Vertical\n^FO120,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO200,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO250,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO297,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO400,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO450,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO510,185\n^GB0,170,1^FS\n\n^FX Line Horizontal\n^FO450,185\n^GB130,0,1^FS\n\n"
                        "^FX QR code\n^FT70,"+str(355+adjust_vertical_inner)+",0\n^BQN,2,5,H,7\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(qty_innerbox)+"|E:"+str(exp_date)+"^FS\n\n"
                        "^FX Batch readable\n^FO80,30\n^ABB25,25,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB130,1,,C\n^FD"+str(no_batch)+"^FS\n\n"
                        "^FX Operator readable\n^FO135,20\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDOP:"+str(operator_innerbox)+"^FS\n \n"
                        "^FX SN Title readable\n^FO165,120\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB40,1,,L\n^FDSN:^FS\n \n^FX SN Value readable\n^FO165,30\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB100,2,,L\n^FD"+str(counter_last)+"_"+str(snfg_id)+"^FS\n\n"
                        "^FX Line readable\n^FO215,20\n^A0B20,20,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDLINE : "+str(nama_line)+"^FS\n\n"
                        "^FX Odoo Code readable\r\n^FO265,155\r\n^A0B23,23,B:CYRI_UB.FNT\r\n^FX Field block 500 dots wide, 3 lines max\r\n^FB240,2,,R\r\n^FDODOO CODE : "+kode_odoo+"^FS\r\n\r\n"
                        "^FX Item Name Label\n^FO303,267\n^ABB,15,10\n^FDItem Name^FS\n\n^FX Item name human readable\n^CI28\n^FO325,33\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB315,3,,L\n^FD"+fg_name_odoo+"^FS\n\n"
                        "^FX SNFG Label\n^FO405,310\n^ABB,15,10\n^FDSNFG^FS\n\n^FX SNFG human readable\n^FO425,40\n^ADB,16\n^FX Field block 500 dots wide, 3 lines max\n^FB300,3,,L\n^FD"+snfg+"^FS\n\n"
                        "^FX NA Number Label\n^FO455,265\n^ABB,15,10\n^FDNA Number^FS\n\n^FX NA Number human readable\n^FO480,182\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB160,1,,L\n^FD"+str(na_number)+"^FS\n\n"
                        "^FX Exp Date Label\n^FO515,247\n^ABB,15,10\n^FDExpiry Date^FS\n\n^FX Exp Date readable\n^FO540,190\n^AQB35,35,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB165,1,,C\n^FD"+str(exp_date)+"^FS\n\n"
                        "^FX Qty er innerbox Label\n^FO455,35\n^ABB,15,10\n^FDQty per innerbox^FS\n\n^FX Qty per innerbox readable\n^FO485,30\n^ABB65,65,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB150,1,,C\n^FD^FD"+str(qty_innerbox)+"^FS\n\n"
                        "^FX inline Title\n^FO565,90\n^AAB5,5\n^FDinline^FS\n\n"
                        "^FX Print quantity\n^PQ1,0,1,Y\n\n"
                        "^FX End label format\n^XZ\n"
                    )


                    args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                    lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                    lpr.stdin.write(json_body.encode("utf-8"))
                    lpr.stdin.close()

                    serialized = json.dumps({ "test":1 }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                if (key == "last_karbox"):
                    print "last label karbox"

                    if (is_innerbox == 1):
                        counter_last = karboxCounter - 1
                    else :
                        counter_last = counter - 1
                    # JIKA ITEM PAKAI KARBOX MALAYSIA, TEMPLATE NYA zpl_malaysia
                    if "MY-" in koitem_fg :
                        # TEMPLATE LABEL MALAYSIA
                        json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                        "^FX Line Vertical\r\n^FO330,145\r\n^GB0,110,1^FS\r\n\r\n^FX Line Vertical\r\n^FO400,255\r\n^GB0,105,1^FS\r\n\r\n^FX Line Vertical\r\n^FO220,255\r\n^GB0,60,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,145\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,195\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,255\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,315\r\n^GB350,0,1^FS\r\n\r\n"
                                        "^FX QR code\r\n^FT50,"+str(140+adjust_vertical)+",0\r\n^BQN,2,3,Q,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n\r\n"
                                        "^FX ODOO CODE human readable\r\n^FO175,25\r\n^ADN,16\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                        "^FX Item name human readable\r\n^CI28\r\n^FO175,50\r\n^ARN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB385,3,,\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                        "^FX SNFG Title\r\n^FO50,150\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO50,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB280,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                        "^FX SMB Title\r\n^FO340,150\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO340,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                        "^FX Lakban human readable\r\n^FO50,215\r\n^AQN15,15\r\n\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB265,1,,C ^FD"+warna+"^FS\r\n\r\n"
                                        "^FX Exp Date Title\r\n^FO340,200\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO340,222\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                        "^FX Batch Title\r\n^FO50,265\r\n^ABN5,5\r\n^FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO50,282\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                        "^FX Operator\r\n^FO225,260\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO225,285\r\n^AQN15,15\r\n^FDSN : "+str(counter_last)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                        "^FX Qty per box Title\r\n^FO410,266\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO410,285\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                        "^FX EAN-13\r\n^FO150,321^BY2\r\n^BEN,20,Y,N\r\n^FD"+str(barcode)+"^FS\r\n\r\n"
                                        "^FX inline Title ^FO450,340 ^AAN15,15 ^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                    else :
                        print "last label non malaysia"


                        if len(fg_name_odoo)>70 :
                            # TEMPLATE LABEL KARBOX NON-MALAYSIA
                            json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                                "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                                "^FX ODOO CODE human readable\r\n^FO230,20\r\n^A0N23,23,B:CYRI_UB.FNT\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^A0N,23 ^FB340,4,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                                "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(counter_last)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                                "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                        else :
                            # TEMPLATE LABEL KARBOX NON-MALAYSIA
                            json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                                "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                                "^FX ODOO CODE human readable\r\n^FO230,20\r\n^A0N23,23,B:CYRI_UB.FNT\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^A0N,26 ^FB340,3,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                                "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(counter_last)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                                "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")


                    args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                    lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                    lpr.stdin.write(json_body.encode("utf-8"))
                    lpr.stdin.close()

                    serialized = json.dumps({ "test":1 }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK MENGURANGI JUMLAH COUNTER KETIKA ADA DELETE DATA DI TABLET
                if (key=="delete"):
                    # innerCounter -= 1
                    serialized = json.dumps({ "delete":innerCounter }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK GET DATA PERTAMA KALI
                if (key=="new"):
                    isNew = True
                    serialized = json.dumps({ "isNew":1 }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK PERINTAH RESET COUNTER MENJADI 0
                if (key=="reset_counter"):
                    # innerCounter = 0
                    serialized = json.dumps({ "reset_counter":1 }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK PERINTAH MENGAKTIFKAN TARE
                if (key=="tare_on"):
                    tareOn = True
                    serialized = json.dumps({ "tareStatus":'on' }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK PERINTAH NONAKTIFKAN TARE
                if (key=="tare_off"):
                    tareOn = False
                    serialized = json.dumps({ "tareStatus":'off' }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK MEMBERIKAN INFORMASI BERAPA JUMLAH COUNTER SAAT INI
                if (key=="counter"):

                    # print('innerCounter')
                    # print(innerCounter)
                    serialized = json.dumps({ "counter":innerCounter-1 }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK MEMBERIKAN INFORMASI BERAPA JUMLAH COUNTER SAAT INI
                if (key=="code_version"):

                    # print('innerCounter')
                    # print(innerCounter)
                    serialized = json.dumps({ "code_version":'2022-18-08 : counter karbox innerbox' }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)


                # API UNTUK PRINT CONTOH LABEL DI AWAL JADWAL (DENGAN NOMOR SN 0_snfgid)
                if (key=="awal"):
                    counter_last = 0
                    if (is_innerbox == 1) :
                        # CODE UNTUK PRINT INNERBOX
                        json_body = (
                            "^FX Begin setup\n^XA\n~TA120\n~JSN\n^LT0\n^MNW\n^MTT\n^PON\n^PMN\n^LH0,0\n^JMA\n^PR4,4\n~SD25\n^JUS\n^LRN\n^CI0\n^MD0\n^XZ\n^FX End setup\n\n"
                            "^FX Begin label format\n^XA\n^MMT\n^LL0254\n^PW629\n^LS0\n\n^FX Box-line Vertical\n^FO55,25\n^GB0,330,2^FS\n\n^FX Box-line Vertical\n^FO580,25\n^GB0,332,2^FS\n\n^FX Box-line Horizontal\n^FO55,25\n^GB525,0,2^FS\n\n^FX Box-line Horizontal\n^FO55,355\n^GB526,0,2^FS\n\n^FX Line Vertical\n^FO120,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO200,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO250,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO297,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO400,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO450,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO510,185\n^GB0,170,1^FS\n\n^FX Line Horizontal\n^FO450,185\n^GB130,0,1^FS\n\n"
                            "^FX QR code\n^FT70,"+str(355+adjust_vertical_inner)+",0\n^BQN,2,5,H,7\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(qty_innerbox)+"|E:"+str(exp_date)+"^FS\n\n"
                            "^FX Batch readable\n^FO80,30\n^ABB25,25,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB130,1,,C\n^FD"+str(no_batch)+"^FS\n\n"
                            "^FX Operator readable\n^FO135,20\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDOP:"+str(operator_innerbox)+"^FS\n \n"
                            "^FX SN Title readable\n^FO165,120\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB40,1,,L\n^FDSN:^FS\n \n^FX SN Value readable\n^FO165,30\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB100,2,,L\n^FD"+str(counter_last)+"_"+str(snfg_id)+"^FS\n\n"
                            "^FX Line readable\n^FO215,20\n^A0B20,20,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDLINE : "+str(nama_line)+"^FS\n\n"
                            "^FX Odoo Code readable\r\n^FO265,155\r\n^A0B23,23,B:CYRI_UB.FNT\r\n^FX Field block 500 dots wide, 3 lines max\r\n^FB240,2,,R\r\n^FDODOO CODE : "+kode_odoo+"^FS\r\n\r\n"
                            "^FX Item Name Label\n^FO303,267\n^ABB,15,10\n^FDItem Name^FS\n\n^FX Item name human readable\n^CI28\n^FO325,33\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB315,3,,L\n^FD"+fg_name_odoo+"^FS\n\n"
                            "^FX SNFG Label\n^FO405,310\n^ABB,15,10\n^FDSNFG^FS\n\n^FX SNFG human readable\n^FO425,40\n^ADB,16\n^FX Field block 500 dots wide, 3 lines max\n^FB300,3,,L\n^FD"+snfg+"^FS\n\n"
                            "^FX NA Number Label\n^FO455,265\n^ABB,15,10\n^FDNA Number^FS\n\n^FX NA Number human readable\n^FO480,182\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB160,1,,L\n^FD"+str(na_number)+"^FS\n\n"
                            "^FX Exp Date Label\n^FO515,247\n^ABB,15,10\n^FDExpiry Date^FS\n\n^FX Exp Date readable\n^FO540,190\n^AQB35,35,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB165,1,,C\n^FD"+str(exp_date)+"^FS\n\n"
                            "^FX Qty er innerbox Label\n^FO455,35\n^ABB,15,10\n^FDQty per innerbox^FS\n\n^FX Qty per innerbox readable\n^FO485,30\n^ABB65,65,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB150,1,,C\n^FD^FD"+str(qty_innerbox)+"^FS\n\n"
                            "^FX inline Title\n^FO565,90\n^AAB5,5\n^FDinline^FS\n\n"
                            "^FX Print quantity\n^PQ1,0,1,Y\n\n"
                            "^FX End label format\n^XZ\n"
                        )

                        args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                        lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                        lpr.stdin.write(json_body.encode("utf-8"))
                        lpr.stdin.close()
                    if "MY-" in (json_array[0]['koitem_fg']) :
                        json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                                        "^FX Line Vertical\r\n^FO330,145\r\n^GB0,110,1^FS\r\n\r\n^FX Line Vertical\r\n^FO400,255\r\n^GB0,105,1^FS\r\n\r\n^FX Line Vertical\r\n^FO220,255\r\n^GB0,60,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,145\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,195\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,255\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,315\r\n^GB350,0,1^FS\r\n\r\n"
                                                        "^FX QR code\r\n^FT50,"+str(140+adjust_vertical)+",0\r\n^BQN,2,3,Q,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n\r\n"
                                                        "^FX ODOO CODE human readable\r\n^FO175,25\r\n^ADN,16\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                                                        "^FX Item name human readable\r\n^CI28\r\n^FO175,50\r\n^ARN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB385,3,,\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                                        "^FX SNFG Title\r\n^FO50,150\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO50,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB280,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                                        "^FX SMB Title\r\n^FO340,150\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO340,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                                                        "^FX Lakban human readable\r\n^FO50,215\r\n^AQN15,15\r\n\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB265,1,,C ^FD"+warna+"^FS\r\n\r\n"
                                                        "^FX Exp Date Title\r\n^FO340,200\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO340,222\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                                                        "^FX Batch Title\r\n^FO50,265\r\n^ABN5,5\r\n^FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO50,282\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                                                        "^FX Operator\r\n^FO225,260\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO225,285\r\n^AQN15,15\r\n^FDSN : "+str(counter_last)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                                        "^FX Qty per box Title\r\n^FO410,266\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO410,285\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                                        "^FX EAN-13\r\n^FO150,321^BY2\r\n^BEN,20,Y,N\r\n^FD"+str(barcode)+"^FS\r\n\r\n"
                                                        "^FX inline Title ^FO450,340 ^AAN15,15 ^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                        args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                        lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                        lpr.stdin.write(json_body.encode("utf-8"))
                        lpr.stdin.close()
                        print "awal malaysia"
                    else :

                        json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                            "^FX Line Vertical\r\n^FO220,5\r\n^GB0,340,2^FS\r\n\r\n^FX Line Vertical\r\n^FO460,240\r\n^GB0,105,1^FS\r\n\r\n^FX Line Horizontal DIatas SNFG\r\n^FO220,133\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Batch\r\n^FO45,210\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas OP SN\r\n^FO45,250\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Lakban Warna\r\n^FO45,310\r\n^GB175,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Na Number\r\n^FO220,185\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas Exp Date\r\n^FO220,240\r\n^GB320,0,1^FS\r\n\r\n^FX Line Horizontal Diatas SMB\r\n^FO220,300\r\n^GB240,0,1^FS\r\n\r\n"
                            "^FX QR code\r\n^FT50,"+str(215+adjust_vertical)+"\r\n^BQN,2,5,H,7\r\n^FDM,C:"+str(barcode)+"|O:"+str(kode_odoo)+"|B:"+str(no_batch)+"|Q:"+str(quantity)+"|E:"+str(exp_date)+"^FS\r\n\r\n"
                            "^FX ODOO CODE human readable\r\n^FO230,20\r\n^A0N23,23,B:CYRI_UB.FNT\r\n^FH\\^FDODOO CODE: "+kode_odoo+"^FS\r\n\r\n"
                            "^FX Item name human readable\r\n^CI28\r\n^FO230,45\r\n^FX Field block 507 dots wide, 3 lines max\r\n^A0N,26 ^FB340,3,,\r\n\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                            "^FX SNFG Title\r\n^FO230,140\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO230,155\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB360,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                            "^FX SMB Title\r\n^FO230,310\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO230,325\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(no_smb)+"^FS\r\n\r\n"
                            "^FX NA Number Title\r\n^FO230,190\r\n^ABN5,5\r\n^FDNA Number^FS\r\n\r\n^FX NA Number human readable\r\n^FO230,210\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB275,1,,C\r\n^FD"+str(na_number)+"^FS\r\n\r\n"
                            "^FX Exp Date Title\r\n^FO230,250\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO230,267\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+str(exp_date)+"^FS\r\n\r\n"
                            "^FX Batch Title\r\n^FX FO45,190\r\n^FX ABN5,5\r\n^FX FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO45,220\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+str(no_batch)+"^FS\r\n\r\n"
                            "^FX Operator\r\n^FO45,255\r\n^AQN15,15\r\n^FDOP : "+str(operator)+"^FS\r\n\r\n^FX SN\r\n^FO45,280\r\n^AQN15,15\r\n^FDSN : "+str(counter_last)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                            "^FX Qty per box Title\r\n^FO470,250\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO455,270\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                            "^FX Lakban human readable\r\n^FO45,318\r\n^ANN25,25\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB150,2,,C\r\n^FD"+warna+"^FS\r\n\r\n"
                            "^FX inline Title\r\n^FO490,340\r\n^AAN15,15\r\n^FDinline^FS\r\n\r\n^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")

                        args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                        lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                        lpr.stdin.write(json_body.encode("utf-8"))
                        lpr.stdin.close()
                        print "awal reguler"

                    serialized = json.dumps({ "test": "berhasil" }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

        else :
            # API DEFAULT UNTUK CEK STATUS PRINTER
            args = shlex.split("lpstat -p Zebra_Technologies_ZTC_GT800_")
            output = subprocess.Popen( args, stdout=subprocess.PIPE ).communicate()[0]
            splitted = output.split()
            if (len(output.split()) <= 13 and splitted[3] == "idle."):
                printerStatus = "connected"
            elif (len(output.split()) <= 13 and splitted[3] == "printing") :
                printerStatus = "printing"
            else:
                printerStatus = "disconnected"
            serialized = json.dumps({ "printer":printerStatus }, sort_keys=True, indent=3)
            self.wfile.write(serialized)
##########################################################################################

##########################################################################################
#
# MAIN PROGRAM
#
##########################################################################################

#Create Class
weighing = weighingPrintingOnline()
#Create Thread
WeighingThread = Thread(target=weighing.run)
#Start Thread
WeighingThread.start()

try:
    #Set locale timestamp to Indonesia
    os.environ['TZ'] = 'Asia/Jakarta'
    time.tzset()
    # locale.setlocale(locale.LC_ALL,'id_ID.UTF8')
    # Create a web server and define the handler to manage the
    # Incoming request
    server = HTTPServer(('', PORT_NUMBER), apiHandler)
    print 'Started httpserver on port ' , PORT_NUMBER
    # print ('Started httpserver on port ' , PORT_NUMBER)

    # Wait forever for incoming htto requests
    server.serve_forever()

except KeyboardInterrupt:
    print '^C received, shutting down the web server'
    # print ('^C received, shutting down the web server')
    server.socket.close()
    weighing.terminate()
##########################################################################################
