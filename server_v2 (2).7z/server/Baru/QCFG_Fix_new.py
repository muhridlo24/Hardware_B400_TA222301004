#UPDATE ADD CATCH ERROR
##########################################################################################
#
# LIBRARY
#
##########################################################################################
from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
from time import sleep
import RPi.GPIO as io
from threading import Thread
import time
import json
import subprocess
import shlex
import requests
import urllib2
from datetime import datetime
import urlparse

threshold = 17
##########################################################################################

##########################################################################################
#
# SETUP
#
##########################################################################################

#Setting : GPIO Raspberry
io.setmode(io.BCM)          # Akses io menggunakan nama pin standar(GPIO 21)
io.setup(20,io.IN, pull_up_down=io.PUD_DOWN)          # Membuat GPIO 21 sebagai input
io.setup(21,io.IN, pull_up_down=io.PUD_DOWN)  
io.setup(16,io.IN, pull_up_down=io.PUD_DOWN)  
print ("Starting....") # print sesuatu
print (" Press Ctrl+C to quit")   # print sesuatu
# Setting Socket
PORT_NUMBER = 6900

# API Endpoint 
url = "http://10.3.5.102:3000/flow_input_snfg_wo" #POST response to activate the counter in server

headers = {
    'content-type': "application/json",
    'cache-control': "no-cache",
    'postman-token': "964aef80-13fe-1d10-5309-96345ebb4732"
    }
##########################################################################################

##########################################################################################
#
# VARIABLE
#
##########################################################################################

# Variabel for counting
a = 0
b = 0
c = 0
data = 0
tag = True
tagLess = True
tagOver = True
first = False
json_array = ""
isError = False
lastCounter = 0
counter = 0
offlineCounter = 0
json_body = ""
json_body2 = ""

operator = ""
item_name = ""
quantity = 0
no_batch = ""
exp_date = ""
snfg_id = 0
koitem_fg = ""
kode_odoo = ""
snfg = ""
no_smb = ""
warna = ""
barcode = ""
na_number = ""
fg_name_odoo = ""
nama_line = ""
qty_innerbox = 0
is_innerbox = 0
isPrint = False
once = True
innerCounter = 0
batas = 0
flag = 1
is_counter = 0
datetime_stop = ""
##########################################################################################

##########################################################################################
#
# FUNCTION DEFINITION
#
##########################################################################################
class weighingPrintingOnline:  
    def __init__(self):
        self._running = True
        
    def terminate(self):  
        self._running = False  
        
    def run(self):
        global a
        global b
        global c
        global data
        global tag
        global tagLess
        global tagOver
        global threshold
        global json_array
        global koitem_fg
        global operator
        global exp_date
        global item_name
        global kode_odoo
        global snfg
        global snfg_id
        global no_smb
        global no_batch
        global quantity
        global json_body
        global offlineCounter
        global isError
        global lastCounter
        global first
        global counter
        global isPrint
        global once
        global warna
        global barcode
        global na_number
        global fg_name_odoo
        global qty_innerbox
        global is_innerbox
        global nama_line
        global innerCounter
        global batas
        global flag
        global json_body2
        global is_counter
        global datetime_stop

        while self._running:
            time.sleep(0.1) # 100ms delay
            if (io.input(16) == 0) :
                a+=1
                b=0
                c=0
            elif (io.input(21) == 0) :
                b+=1
                a=0
                c=0
            elif (io.input(20) == 0) :
                c+=1
                a=0
                b=0
            else :
                a=0
                b=0
                c=0
                tag = True
                tagLess = True
                tagOver = True
                
            # KONDISI KETIKA TIMBANGAN MEERAH / OVER
            if (a>threshold and tagOver): # DELAY AGAR MENUNGGU TIMBANGAN STABIL. (a x 100ms)
                tagOver = False
                if (not(isError)):
                    try :
                        contents = urllib2.urlopen("http://10.3.5.102:3000/api_weigher_snfg?nama_line=plfts.BOP08").read()
                        json_array = json.loads(contents)
                        
                        if (json_array[0]['status'] != "tare_on") :
                            # KIRIM DATA STATUS TIMBANG MERAH KE SERVER, AGAR MUNCUL DI TABLET
                            payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(json_array[0]['nama_operator'])+"\",\"write_time\":\""+datetime.now().strftime("%Y-%m-%dT%H:%M:%S")+"\",\"nourut\":"+str(json_array[0]['cur_seq'])+",\"status\":\"over\"}"
                            response = requests.request("POST", url, data=payload, headers=headers)
                    except :
                        # KETIKA OFFLINE (TRY CONNECT GAGAL), MENYIMPAN DATA TERAKHIR KE VARIABEL
                        print ("Offline Mode")
                        isError = True
                        first = True
                        lastCounter = json_array[0]['cur_seq']
                        operator = json_array[0]['nama_operator']
                        item_name = json_array[0]['nama_fg']
                        quantity = json_array[0]['koli']
                        no_batch = json_array[0]['nobatch']
                        exp_date = json_array[0]['exp_date']
                        kode_odoo = json_array[0]['odoo_code']
                        snfg_id = json_array[0]['id']
                        koitem_fg = json_array[0]['koitem_fg']
                        snfg = json_array[0]['snfg']
                        no_smb = json_array[0]['nosmb']
                        warna = json_array[0]['warna']
                        barcode = json_array[0]['barcode']
                        na_number = json_array[0]['na_number']
                        fg_name_odoo = json_array[0]['fg_name_odoo']
                        qty_innerbox = json_array[0]['qty_innerbox']
                        is_innerbox = json_array[0]['is_innerbox']
                        nama_line = json_array[0]['nama_line']
                        is_counter = json_array[0]['is_counter']
                        if ((json_array[0]['is_print'] == 1) and (not json_array[0]['datetime_stop'])) :
                            isPrint = True
                        else :
                            isPrint = False

            # KONDISI KETIKA TIMBANGAN HIJAU            
            if (b>3 and tag): # DELAY AGAR MENUNGGU TIMBANGAN STABIL. (3 x 100ms)
                tag = False
                if (not(isError)):
                    try :
                        contents = urllib2.urlopen("http://10.3.5.102:3000/api_weigher_snfg?nama_line=plfts.BOP08").read()
                        json_array = json.loads(contents)

                        # KETIKA PAKAI COUNTER, MAKA BACA BATAS COUNTER
                        if (json_array[0]['is_counter'] == 1) : # is_counter DARI TABEL weigher_fg_map_device
                            batas = json_array[0]['koli'] / json_array[0]['qty_innerbox']
                        
                        # LOGIC UNTUK PRINT
                        #
                        # KETIKA KONDISI TARE OFF -> BOLEH PRINT (TOMBOL DI TABLET) 
                        if not json_array[0]['datetime_stop'] :
                            if (json_array[0]['status'] != "tare_on") :
                                # KETIKA BOLEH PRINT (is_print dapat dari jenis proses nya), FILLING HARUSNYA GA PRINT
                                if (json_array[0]['is_print'] == 1) :
                                    args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                                    lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                                    # JIKA ITEM TIDAK PAKAI INNERBOX
                                    if (json_array[0]['is_innerbox'] != 1) :
                                        # JIKA ITEM PAKAI KARBOX MALAYSIA, TEMPLATE NYA zpl_malaysia
                                        if "MY-" in (json_array[0]['koitem_fg']) :
                                            lpr.stdin.write(json_array[0]['zpl_malaysia'].encode("utf-8"))
                                            lpr.stdin.close()
                                        # JIKA ITEM PAKAI KARBOX NON-MALAYSIA, TEMPLATE NYA zpl2
                                        else :
                                            lpr.stdin.write(json_array[0]['zpl2'].encode("utf-8"))
                                            lpr.stdin.close()
                                    # JIKA ITEM PAKAI INNERBOX, TEMPLATE NYA zpl
                                    else :
                                        # CODE UNTUK PRINT INNERBOX
                                        lpr.stdin.write(json_array[0]['zpl'].encode("utf-8"))
                                        lpr.stdin.close()

                                        # CODE UNTUK PRINT JIKA LINE NYA PAKAI COUNTER
                                        if (json_array[0]['is_counter'] == 1) :
                                            innerCounter += 1 # ADD COUNTER (khusus mode counter)
                                            if (innerCounter == batas) :
                                                args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                                                lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                                                lpr.stdin.write(json_array[0]['zpl2'].encode("utf-8"))
                                                lpr.stdin.close()
                                                innerCounter = 0
                                    
                            # KIRIM DATA STATUS TIMBANG HIJAU KE SERVER, AGAR MUNCUL DI TABLET
                            payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(json_array[0]['nama_operator'])+"\",\"write_time\":\""+datetime.now().strftime("%Y-%m-%dT%H:%M:%S")+"\",\"nourut\":"+str(json_array[0]['cur_seq'])+",\"status\":\"pass\"}"
                            response = requests.request("POST", url, data=payload, headers=headers)
                    except :
                        # KETIKA OFFLINE (TRY CONNECT GAGAL), MENYIMPAN DATA TERAKHIR KE VARIABEL
                        print ("Offline Mode")
                        isError = True
                        isError = True
                        first = True
                        lastCounter = json_array[0]['cur_seq']
                        operator = json_array[0]['nama_operator']
                        item_name = json_array[0]['nama_fg']
                        quantity = json_array[0]['koli']
                        no_batch = json_array[0]['nobatch']
                        exp_date = json_array[0]['exp_date']
                        kode_odoo = json_array[0]['odoo_code']
                        snfg_id = json_array[0]['id']
                        koitem_fg = json_array[0]['koitem_fg']
                        snfg = json_array[0]['snfg']
                        no_smb = json_array[0]['nosmb']
                        warna = json_array[0]['warna']
                        barcode = json_array[0]['barcode']
                        na_number = json_array[0]['na_number']
                        fg_name_odoo = json_array[0]['fg_name_odoo']
                        qty_innerbox = json_array[0]['qty_innerbox']
                        is_innerbox = json_array[0]['is_innerbox']
                        nama_line = json_array[0]['nama_line']
                        is_counter = json_array[0]['is_counter']
                        if ((json_array[0]['is_print'] == 1) and (not json_array[0]['datetime_stop'])) :
                            isPrint = True
                        else :
                            isPrint = False
                  
                # KETIKA PROGRAM OFFLINE, PERLU PRINT DARI TEMPLATE YANG TERSIMPAN DI LOCAL          
                if (isError):
                    # FLAG PRINT COUNTER KETIKA OFFLINE
                    if (first):
                        counter = lastCounter+1
                        offlineCounter = 0
                        first = False

                    if (isPrint == 1) :
                        if (is_innerbox != 1) :
                            if "MY-" in koitem_fg :
                                # TEMPLATE LABEL MALAYSIA
                                json_body = ("^FX Begin setup\r\n^XA\r\n~TA120\r\n~JSN\r\n^LT0\r\n^MNW\r\n^MTT\r\n^PON\r\n^PMN\r\n^LH0,0\r\n^JMA\r\n^PR4,4\r\n~SD25\r\n^JUS\r\n^LRN\r\n^MD0\r\n^CI0\r\n^XZ\r\n^FX End setup\r\n\r\n^FX Begin label format\r\n^XA\r\n^MMT\r\n^LL0254\r\n^PW629\r\n^LS0\r\n\r\n"
                                             "^FX Line Vertical\r\n^FO330,145\r\n^GB0,110,1^FS\r\n\r\n^FX Line Vertical\r\n^FO400,255\r\n^GB0,105,1^FS\r\n\r\n^FX Line Vertical\r\n^FO220,255\r\n^GB0,60,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,145\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,195\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,255\r\n^GB525,0,1^FS\r\n\r\n^FX Line Horizontal\r\n^FO50,315\r\n^GB350,0,1^FS\r\n\r\n"
                                             "^FX QR code\r\n^FT50,140,0\r\n^BQN,2,3,Q,7\r\n^FDM,C:"+barcode+"|O:"+kode_odoo+"|B:"+no_batch+"|Q:"+str(quantity)+"|E:"+exp_date+"^FS\r\n\r\n\r\n"
                                             "^FX SKU human readable\r\n^FO175,25\r\n^ADN,16\r\n^FH\\^FDSKU: "+koitem_fg+"^FS\r\n\r\n"
                                             "^FX Item name human readable\r\n^FO175,50\r\n^ARN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB385,3,,\r\n^FD"+fg_name_odoo+"^FS\r\n\r\n"
                                             "^FX SNFG Title\r\n^FO50,150\r\n^ABN5,5\r\n^FDSNFG^FS\r\n\r\n^FX SNFG human readable\r\n^FO50,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB280,1,,C\r\n^FD"+snfg+"^FS\r\n\r\n"
                                             "^FX SMB Title\r\n^FO340,150\r\n^ABN5,5\r\n^FDSMB^FS\r\n\r\n^FX SMB human readable\r\n^FO340,170\r\n^ADN,16\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+no_smb+"^FS\r\n\r\n"
                                             "^FX Lakban human readable\r\n^FO50,215\r\n^AQN15,15\r\n\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB265,1,,C ^FD"+warna+"^FS\r\n\r\n"
                                             "^FX Exp Date Title\r\n^FO340,200\r\n^ABN5,5\r\n^FDExp Date^FS\r\n\r\n^FX Exp Date human readable\r\n^FO340,222\r\n^APN,35,35\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB235,1,,C\r\n^FD"+exp_date+"^FS\r\n\r\n"
                                             "^FX Batch Title\r\n^FO50,265\r\n^ABN5,5\r\n^FDBatch^FS\r\n\r\n^FX Batch human readable\r\n^FO50,282\r\n^ARN,45,40\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB168,1,,C\r\n^FD"+no_batch+"^FS\r\n\r\n"
                                             "^FX Operator\r\n^FO225,260\r\n^AQN15,15\r\n^FDOP : "+operator+"^FS\r\n\r\n^FX SN\r\n^FO225,285\r\n^AQN15,15\r\n^FDSN : "+str(counter)+"_"+str(snfg_id)+"^FS\r\n\r\n"
                                             "^FX Qty per box Title\r\n^FO410,266\r\n^ABN5,5\r\n^FDQty per Box^FS\r\n\r\n^FX Qty per Box human readable\r\n^FO410,285\r\n^APN,95,95\r\n^FX Field block 507 dots wide, 3 lines max\r\n^FB160,1,,C\r\n^FD"+str(quantity)+"^FS\r\n\r\n"
                                             "^FX EAN-13\r\n^FO150,321^BY2\r\n^BEN,20,Y,N\r\n^FD"+barcode+"^FS\r\n\r\n"
                                             "^FX Print quantity\r\n^PQ1,0,1,Y\r\n\r\n^FX End label format\r\n^XZ")
                            else :
                                # TEMPLATE LABEL KARBOX NON-MALAYSIA
                                json_body = ("^FX Begin setup\n^XA\n~TA120\n~JSN\n^LT0\n^MNW\n^MTT\n^PON\n^PMN\n^LH0,0\n^JMA\n^PR4,4\n~SD25\n^JUS\n^LRN\n^MD0\n^CI0\n^XZ\n^FX End setup\n\n^FX Begin label format\n^XA\n^MMT\n^LL0254\n^PW629\n^LS0\n\n"
                                   "^FX Line Vertical\n^FO220,5\n^GB0,340,2^FS\n\n^FX Line Vertical\n^FO460,240\n^GB0,105,1^FS\n\n^FX Line Horizontal\n^FO220,133\n^GB320,0,1^FS\n\n^FX Line Horizontal\n^FO45,185\n^GB495,0,1^FS\n\n^FX Line Horizontal\n^FO45,240\n^GB495,0,1^FS\n\n^FX Line Horizontal\n^FO45,300\n^GB415,0,1^FS\n\n"
                                   "^FX QR code\n^FO50,5,0\n^BQN,2,5,H,7\n^FDM,C:"+barcode+"|O:"+kode_odoo+"|B:"+no_batch+"|Q:"+str(quantity)+"|E:"+exp_date+"^FS\n\n"
                                   "^FX SKU human readable\n^FO230,20\n^ADN,16\n^FH\\^FDSKU: "+koitem_fg+"^FS\n\n"
                                   "^FX Item name human readable\n^FO230,45\n^ARN,16\n^FX Field block 507 dots wide, 3 lines max\n^FB360,3,,\n^FD"+fg_name_odoo+"^FS\n\n"
                                   "^FX SNFG Title\n^FO230,140\n^ABN5,5\n^FDSNFG^FS\n\n^FX SNFG human readable\n^FO230,155\n^ADN,16\n^FX Field block 507 dots wide, 3 lines max\n^FB280,1,,C\n^FD"+snfg+"^FS\n\n"
                                   "^FX SMB Title\n^FO230,310\n^ABN5,5\n^FDSMB^FS\n\n^FX SMB human readable\n^FO230,325\n^ADN,16\n^FX Field block 507 dots wide, 3 lines max\n^FB235,1,,C\n^FD"+no_smb+"^FS\n\n"
                                   "^FX NA Number Title\n^FO230,190\n^ABN5,5\n^FDNA Number^FS\n\n^FX NA Number human readable\n^FO230,210\n^APN,35,35\n^FX Field block 507 dots wide, 3 lines max\n^FB275,1,,C\n^FD"+na_number+"^FS\n\n"
                                   "^FX Exp Date Title\n^FO230,250\n^ABN5,5\n^FDExp Date^FS\n\n^FX Exp Date human readable\n^FO230,267\n^APN,35,35\n^FX Field block 507 dots wide, 3 lines max\n^FB235,1,,C\n^FD"+exp_date+"^FS\n\n"
                                   "^FX Batch Title\n^FO45,190\n^ABN5,5\n^FDBatch^FS\n\n^FX Batch human readable\n^FO45,210\n^ARN,45,40\n^FX Field block 507 dots wide, 3 lines max\n^FB168,1,,C\n^FD"+no_batch+"^FS\n\n"
                                   "^FX Operator\n^FO45,245\n^AQN15,15\n^FDOP : "+operator+"^FS\n\n^FX SN\n^FO45,270\n^AQN15,15\n^FDSN : "+str(counter)+"_"+str(snfg_id)+"^FS\n\n"
                                   "^FX Qty per box Title\n^FO470,250\n^ABN5,5\n^FDQty per Box^FS\n\n^FX Qty per Box human readable\n^FO455,270\n^APN,95,95\n^FX Field block 507 dots wide, 3 lines max\n^FB160,1,,C\n^FD"+str(quantity)+"^FS\n\n"
                                   "^FX Lakban human readable\n^FO45,308\n^ANN25,25\n^FX Field block 507 dots wide, 3 lines max\n^FB150,2,,C\n^FD"+warna+"^FS\n\n"
                                   "^FX Print quantity\n^PQ1,0,1,Y\n\n^FX End label format\n^XZ")
                        else :
                            # TEMPLATE LABEL INNERBOX
                            json_body = ("^FX Begin setup\n^XA\n~TA120\n~JSN\n^LT0\n^MNW\n^MTT\n^PON\n^PMN\n^LH0,0\n^JMA\n^PR4,4\n~SD25\n^JUS\n^LRN\n^CI0\n^MD0\n^XZ\n^FX End setup\n\n"
                                        "^FX Begin label format\n^XA\n^MMT\n^LL0254\n^PW629\n^LS0\n\n"
                                        "^FX Box-line Vertical\n^FO55,25\n^GB0,330,2^FS\n\n^FX Box-line Vertical\n^FO580,25\n^GB0,332,2^FS\n\n^FX Box-line Horizontal\n^FO55,25\n^GB525,0,2^FS\n\n^FX Box-line Horizontal\n^FO55,355\n^GB526,0,2^FS\n\n"
                                        "^FX Line Vertical\n^FO120,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO190,25\n^GB0,140,1^FS\n\n^FX Line Vertical\n^FO250,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO297,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO400,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO450,25\n^GB0,329,1^FS\n\n^FX Line Vertical\n^FO510,185\n^GB0,170,1^FS\n\n"
                                        "^FX Line Horizontal\n^FO450,185\n^GB130,0,1^FS\n\n"
                                        "^FX QR code\n^FT70,355,0\n^BQN,2,5,H,7\n^FDM,C:"+barcode+"|O:"+kode_odoo+"|B:"+no_batch+"|Q:"+str(qty_innerbox)+"|E:"+exp_date+"^FS\n\n"
                                        "^FX Batch readable\n^FO80,30\n^ABB25,25,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB130,1,,C\n^FD"+no_batch+"^FS\n\n"
                                        "^FX Operator readable\n^FO135,20\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDOP:"+operator+"^FS\n\n"
                                        "^FX SN readable\n^FO165,20\n^AOB15,15,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDSN:"+str(counter)+"_"+str(snfg_id)+"^FS\n\n"
                                        "^FX Line readable\n^FO205,20\n^A0B20,20,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB140,1,,L\n^FDLINE : "+nama_line+"^FS\n\n"
                                        "^FX Item Code Label\n^FO255,270\n^ABB,15,10\n^FDItem Code^FS\n\n^FX Item Code readable\n^FO275,18\n^ADB,16\n^FX Field block 500 dots wide, 3 lines max\n^FB320,1,,L\n^FD"+koitem_fg+"^FS\n\n"
                                        "^FX Item Name Label\n^FO303,267\n^ABB,15,10\n^FDItem Name^FS\n\n^FX Item name human readable\n^FO325,33\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB315,3,,L\n^FD"+fg_name_odoo+"^FS\n\n"
                                        "^FX SNFG Label\n^FO405,310\n^ABB,15,10\n^FDSNFG^FS\n\n^FX SNFG human readable\n^FO425,40\n^ADB,16\n^FX Field block 500 dots wide, 3 lines max\n^FB300,3,,L\n^FD"+snfg+"^FS\n\n"
                                        "^FX NA Number Label\n^FO455,265\n^ABB,15,10\n^FDNA Number^FS\n\n^FX NA Number human readable\n^FO480,182\n^AQB10,10,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB160,1,,L\n^FD"+na_number+"^FS\n\n"
                                        "^FX Exp Date Label\n^FO515,247\n^ABB,15,10\n^FDExpiry Date^FS\n\n^FX Exp Date readable\n^FO540,190\n^AQB35,35,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB165,1,,C\n^FD"+exp_date+"^FS\n\n"
                                        "^FX Qty per innerbox Label\n^FO455,35\n^ABB,15,10\n^FDQty per innerbox^FS\n\n^FX Qty per innerbox readable\n^FO485,30\n^ABB65,65,B:CYRI_UB.FNT\n^FX Field block 500 dots wide, 3 lines max\n^FB150,1,,C\n^FD"+qty_innerbox+"^FS\n\n"
                                        "^FX inline Title\n^FO565,90\n^AAB5,5\n^FDinline^FS\n\n"
                                        "^FX Print quantity\n^PQ1,0,1,Y\n\n"
                                        "^FX End label format\n^XZ")

                        args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                        lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                        lpr.stdin.write(json_body.encode("utf-8"))
                        lpr.stdin.close()

                        # JIKA INNER COUNTER MENCAPAI BATAS
                        if (innerCounter == batas) :
                            # TEMPLATE KARBOX NON-MALAYSIA
                            json_body2 = ("^FX Begin setup\n^XA\n~TA120\n~JSN\n^LT0\n^MNW\n^MTT\n^PON\n^PMN\n^LH0,0\n^JMA\n^PR4,4\n~SD25\n^JUS\n^LRN\n^MD0\n^CI0\n^XZ\n^FX End setup\n\n^FX Begin label format\n^XA\n^MMT\n^LL0254\n^PW629\n^LS0\n\n"
                                   "^FX Line Vertical\n^FO220,5\n^GB0,340,2^FS\n\n^FX Line Vertical\n^FO460,240\n^GB0,105,1^FS\n\n^FX Line Horizontal\n^FO220,133\n^GB320,0,1^FS\n\n^FX Line Horizontal\n^FO45,185\n^GB495,0,1^FS\n\n^FX Line Horizontal\n^FO45,240\n^GB495,0,1^FS\n\n^FX Line Horizontal\n^FO45,300\n^GB415,0,1^FS\n\n"
                                   "^FX QR code\n^FO50,5,0\n^BQN,2,5,H,7\n^FDM,C:"+barcode+"|O:"+kode_odoo+"|B:"+no_batch+"|Q:"+str(quantity)+"|E:"+exp_date+"^FS\n\n"
                                   "^FX SKU human readable\n^FO230,20\n^ADN,16\n^FH\\^FDSKU: "+koitem_fg+"^FS\n\n"
                                   "^FX Item name human readable\n^FO230,45\n^ARN,16\n^FX Field block 507 dots wide, 3 lines max\n^FB360,3,,\n^FD"+fg_name_odoo+"^FS\n\n"
                                   "^FX SNFG Title\n^FO230,140\n^ABN5,5\n^FDSNFG^FS\n\n^FX SNFG human readable\n^FO230,155\n^ADN,16\n^FX Field block 507 dots wide, 3 lines max\n^FB280,1,,C\n^FD"+snfg+"^FS\n\n"
                                   "^FX SMB Title\n^FO230,310\n^ABN5,5\n^FDSMB^FS\n\n^FX SMB human readable\n^FO230,325\n^ADN,16\n^FX Field block 507 dots wide, 3 lines max\n^FB235,1,,C\n^FD"+no_smb+"^FS\n\n"
                                   "^FX NA Number Title\n^FO230,190\n^ABN5,5\n^FDNA Number^FS\n\n^FX NA Number human readable\n^FO230,210\n^APN,35,35\n^FX Field block 507 dots wide, 3 lines max\n^FB275,1,,C\n^FD"+na_number+"^FS\n\n"
                                   "^FX Exp Date Title\n^FO230,250\n^ABN5,5\n^FDExp Date^FS\n\n^FX Exp Date human readable\n^FO230,267\n^APN,35,35\n^FX Field block 507 dots wide, 3 lines max\n^FB235,1,,C\n^FD"+exp_date+"^FS\n\n"
                                   "^FX Batch Title\n^FO45,190\n^ABN5,5\n^FDBatch^FS\n\n^FX Batch human readable\n^FO45,210\n^ARN,45,40\n^FX Field block 507 dots wide, 3 lines max\n^FB168,1,,C\n^FD"+no_batch+"^FS\n\n"
                                   "^FX Operator\n^FO45,245\n^AQN15,15\n^FDOP : "+operator+"^FS\n\n^FX SN\n^FO45,270\n^AQN15,15\n^FDSN : "+str(counter)+"_"+str(snfg_id)+"^FS\n\n"
                                   "^FX Qty per box Title\n^FO470,250\n^ABN5,5\n^FDQty per Box^FS\n\n^FX Qty per Box human readable\n^FO455,270\n^APN,95,95\n^FX Field block 507 dots wide, 3 lines max\n^FB160,1,,C\n^FD"+str(quantity)+"^FS\n\n"
                                   "^FX Lakban human readable\n^FO45,308\n^ANN25,25\n^FX Field block 507 dots wide, 3 lines max\n^FB150,2,,C\n^FD"+warna+"^FS\n\n"
                                   "^FX Print quantity\n^PQ1,0,1,Y\n\n^FX End label format\n^XZ")

                            args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                            lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                            lpr.stdin.write(json_body2.encode("utf-8"))
                            lpr.stdin.close()
                            innerCounter = 0 # RESET COUNTER SETELAH PRINT

                    # COUNTER UNTUK MENGHITUNG SUDAH BERAPA LABEL YANG DI PRINT SELAMA OFFLINE
                    offlineCounter += 1
                    counter += 1
                    if (offlineCounter % 5 == 0):
                        once = True

            # KONDISI KETIKA TIMBANGAN KUNING
            if (c>threshold and tagLess): # DELAY AGAR MENUNGGU TIMBANGAN STABIL. (c x 100ms)
                tagLess = False
                if (not(isError)):
                    try :
                        contents = urllib2.urlopen("http://10.3.5.102:3000/api_weigher_snfg?nama_line=plfts.BOP08").read()
                        json_array = json.loads(contents)

                        # KIRIM DATA STATUS TIMBANG MERAH KE SERVER, AGAR MUNCUL DI TABLET
                        if (json_array[0]['status'] != "tare_on") :
                            payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(json_array[0]['nama_operator'])+"\",\"write_time\":\""+datetime.now().strftime("%Y-%m-%dT%H:%M:%S")+"\",\"nourut\":"+str(json_array[0]['cur_seq'])+",\"status\":\"less\"}"
                            response = requests.request("POST", url, data=payload, headers=headers)
                    except :
                        # KETIKA OFFLINE (TRY CONNECT GAGAL), MENYIMPAN DATA TERAKHIR KE VARIABEL
                        print ("Offline Mode")
                        isError = True
                        first = True
                        lastCounter = json_array[0]['cur_seq']
                        operator = json_array[0]['nama_operator']
                        item_name = json_array[0]['nama_fg']
                        quantity = json_array[0]['koli']
                        no_batch = json_array[0]['nobatch']
                        exp_date = json_array[0]['exp_date']
                        kode_odoo = json_array[0]['odoo_code']
                        snfg_id = json_array[0]['id']
                        koitem_fg = json_array[0]['koitem_fg']
                        snfg = json_array[0]['snfg']
                        no_smb = json_array[0]['nosmb']
                        warna = json_array[0]['warna']
                        barcode = json_array[0]['barcode']
                        na_number = json_array[0]['na_number']
                        fg_name_odoo = json_array[0]['fg_name_odoo']
                        qty_innerbox = json_array[0]['qty_innerbox']
                        is_innerbox = json_array[0]['is_innerbox']
                        nama_line = json_array[0]['nama_line']
                        is_counter = json_array[0]['is_counter']
                        if ((json_array[0]['is_print'] == 1) and (not json_array[0]['datetime_stop'])) :
                            isPrint = True
                        else :
                            isPrint = False

            # SCRIPT UNTUK CEK APAKAH SUDAH BISA KONEK KE SERVER
            # CEK SETIAP KELIPATAN 5. KETIKA PRINT LABEL 5X DAN KELIPATANNYA
            if (offlineCounter % 5 == 0 and offlineCounter > 0 and once): # 5 menit -> 10
                #print "Masuk pengecekan"
                #print b
                try :
                    contents = urllib2.urlopen("http://10.3.5.102:3000/api_weigher_snfg?nama_line=plfts.BOP08").read()
                    # KIRIM DATA LOG PENIMBANGAN, HANYA YANG HIJAU
                    for x in range((counter-offlineCounter), counter) :
                        payload = "{\"weight\":2,\"flow_input_snfg_id\":"+str(json_array[0]['id'])+",\"pack_date\":\""+str(json_array[0]['pack_date'])+"\",\"exp_date\":\""+str(json_array[0]['exp_date'])+"\",\"nama_operator\":\""+str(json_array[0]['nama_operator'])+"\",\"write_time\":\""+datetime.now().strftime("%Y-%m-%dT%H:%M:%S")+"\",\"nourut\":"+str(x)+",\"status\":\"pass\"}"
                        response = requests.request("POST", url, data=payload, headers=headers)
                    isError = False
                    offlineCounter = 0
                    print ("Back to Online Mode")
                    once = True
                except :
                    isError = True
                    once = False


# API PER CLIENT, KEPERLUAN UNTUK MENERIMA PERINTAH DARI TABLET, ATAU CEK STATUS
class apiHandler(BaseHTTPRequestHandler):
    #Handler for the GET requests
    def do_GET(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Content-type','application/json')
        self.end_headers()
        global innerCounter
        
    # POST JSON
        if "?" in self.path:
            for key,value in dict(urlparse.parse_qsl(self.path.split("?")[1], True)).items():
                # API UNTUK PRINT LABEL TEST
                if (key=="test"):
                    command_line = "lpr -P Zebra_Technologies_ZTC_GT800_ -o raw /home/pi/test.zpl"
                    args = shlex.split(command_line)
                    subprocess.call(args)
                    subprocess.call(args)
                    args = shlex.split("lpstat -p Zebra_Technologies_ZTC_GT800_")
                    output = subprocess.Popen( args, stdout=subprocess.PIPE ).communicate()[0]
                    if (len(output.split()) > 14):
                        serialized = json.dumps({ "test":0 }, sort_keys=True, indent=3)
                        self.wfile.write(serialized)
                    else:
                        serialized = json.dumps({ "test":1 }, sort_keys=True, indent=3)
                        self.wfile.write(serialized)

                # API UNTUK PRINT LABEL TERAKHIR (CONTOH : KETIKA MENGAMBIL LABEL SOBEK, MAKA PERLU PRINT ULANG YANG TERAKHIR)
                if (key=="last"):

                    args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                    lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                    if (json_array[0]['is_innerbox'] != 1) :
                        lpr.stdin.write(json_array[0]['zpl2'].encode("utf-8"))
                        lpr.stdin.close()
                    else :
                        lpr.stdin.write(json_array[0]['zpl'].encode("utf-8"))
                        lpr.stdin.close()
                    serialized = json.dumps({ "test":1 }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK MENGURANGI JUMLAH COUNTER KETIKA ADA DELETE DATA DI TABLET
                if (key=="delete"):
                    innerCounter -= 1
                    serialized = json.dumps({ "delete":innerCounter }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK PERINTAH RESET COUNTER MENJADI 0
                if (key=="reset_counter"):
                    innerCounter = 0
                    serialized = json.dumps({ "status":1 }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK MEMBERIKAN INFORMASI BERAPA JUMLAH COUNTER SAAT INI
                if (key=="counter"):
                    serialized = json.dumps({ "counter":innerCounter }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

                # API UNTUK PRINT CONTOH LABEL DI AWAL JADWAL (DENGAN NOMOR SN 0_snfgid)
                if (key=="awal"):

                    args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                    lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                    lpr.stdin.write(json_array[0]['zpl_awal_innerbox'].encode("utf-8"))
                    lpr.stdin.close()
                    args = ['/usr/bin/lpr', '-P', 'Zebra_Technologies_ZTC_GT800_', '-o raw']
                    lpr =  subprocess.Popen(args, stdin=subprocess.PIPE)
                    lpr.stdin.write(json_array[0]['zpl_new'].encode("utf-8"))
                    lpr.stdin.close()
                    serialized = json.dumps({ "test": "berhasil" }, sort_keys=True, indent=3)
                    self.wfile.write(serialized)

        else :
            # API DEFAULT UNTUK CEK STATUS PRINTER
            args = shlex.split("lpstat -p Zebra_Technologies_ZTC_GT800_")
            output = subprocess.Popen( args, stdout=subprocess.PIPE ).communicate()[0]
            splitted = output.split()
            if (len(output.split()) <= 13 and splitted[3] == "idle."):
                printerStatus = "connected"
            elif (len(output.split()) <= 13 and splitted[3] == "printing") :
                printerStatus = "printing"
            else:
                printerStatus = "disconnected"
            serialized = json.dumps({ "printer":printerStatus }, sort_keys=True, indent=3)
            self.wfile.write(serialized)
##########################################################################################

##########################################################################################
#
# MAIN PROGRAM
#
##########################################################################################

#Create Class
weighing = weighingPrintingOnline()
#Create Thread
WeighingThread = Thread(target=weighing.run) 
#Start Thread 
WeighingThread.start()

try:
    # Create a web server and define the handler to manage the
    # Incoming request
    server = HTTPServer(('', PORT_NUMBER), apiHandler)
    print 'Started httpserver on port ' , PORT_NUMBER

    # Wait forever for incoming htto requests
    server.serve_forever()

except KeyboardInterrupt:
    print '^C received, shutting down the web server'
    server.socket.close()
    weighing.terminate()
##########################################################################################
