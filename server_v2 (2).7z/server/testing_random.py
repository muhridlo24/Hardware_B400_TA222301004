
##########
'''MAIN SERVER CODE'''
##########

import os
import sys
import time
import math
import json
import socket
import select
import logging
import threading
import numpy as np
import RPi.GPIO as GPIO
from datetime import datetime
from collections import deque

from witmotion import IMU
from panel_lamp import check
import sensor_temp
import sensor_rpm

##CHECK CONNECTION
relay_pin = 26
check(relay_pin) 
'''skema looping ngecek tiap second belum'''

SERVER_IP = "10.129.9.48"
SERVER_PORT = 3333
VIBRATION_BUFFER_SIZE = 200

# Global variables
vibration_values = deque(maxlen=VIBRATION_BUFFER_SIZE)

#VIBRATION CALLBACK UPDATE
def callback(msg):
	global imu
	imu.get_acceleration()

def read_vib():
	global imu
	imu.subscribe(callback)
	acc_radial = math.sqrt(((imu.last_a[0]**2) + (imu.last_a[1]**2)))
	return acc_radial

#VIBRATION IN DIFFERENT THREAD
def vibration_list():
	global imu
	global timer
	global vibration_values
	while True:
		#APPEND VIB_LIST
		vibration_values.append(read_vib())
		time.sleep(0.005)

#SERVER DATA LIBRARY
'''coba join tidak dipakai agar lebih cepat kirim data'''		
def collect_data():
	print('DATA COLLECTED')
	global vibration_list
	
	temperature = 0.0
	rpm = 0.0
	temperature = sensor_temp.read_temp()
	#rpm = sensor_rpm.read_rpm()
	rpm = np.random.uniform(2800,2900)
	
	#DATA FORMAT AND DUMP
	data ={
		"LHL01":{
		"timestamp": datetime.now().isoformat("@", "seconds"),
		"performance_log": 
			{
			"temperature": temperature,
			"rpm": rpm,
			"vibration": ",".join(map(str, vibration_list))
			}
		}
	}
	json_data = json.dumps(data).encode('utf-8')
	yield json_data

#SERVER UDP COMMUNICATION
def my_server():
	with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
		sock.bind((SERVER_IP, SERVER_PORT))
		#SERVER INDICATOR
		print('---')
		print('SERVER NOW IS UP')
		print('---')

	while True:
		ready = select.select([sock], [], [], 1.0)

	if ready[0]:
		message, address = sock.recvfrom(10024)
		print(f'Received message from {address[0]}: {message.decode()}')
		sock.sendto(next(data_generator), address)

if __name__ == '__main__':
	global imu
	global timer
	'''belum fail safe jika data kosong dan jika wifi mati'''
	VIBRATION_BUFFER_SIZE = 200

	# Global variables
	vibration_values = deque(maxlen=VIBRATION_BUFFER_SIZE)  
	timer = time.time()
	
	imu = IMU('/dev/ttySC1', 115200)
	imu.set_update_rate(200)
	
	data_generator = collect_data()
	vib_thread = threading.Thread(target = vibration_list)
	vib_thread.daemon = True
	vib_thread.start()
	
	data_thread = threading.Thread(target = collect_data)
	data_thread.daemon = True
	data_thread.start()

	while True:
		if (time.time()-timer) >= 1:
			my_server()
			vibration_values.clear()
			timer = time.time()
	
