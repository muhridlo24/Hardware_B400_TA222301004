'''RPM POLL CODE'''

def poll_rpm():
    import minimalmodbus 
    import Modbus_Settings as MB
    import os
    import sys

    '''Calculate what the register address that should be passed to minimal modbus should be'''
    '''Calculate target speed'''
    read_start = MB.reading_offset - 40001

    ser = minimalmodbus.Instrument(MB.USB_port, MB.mb_address)	
    ser.mode = minimalmodbus.MODE_RTU							
    ser.serial.parity = minimalmodbus.serial.PARITY_EVEN			
    ser.serial.baudrate = MB.baudrate							
    ser.serial.bytesize = MB.bytesize							
    ser.serial.stopbits = MB.stopbits 							
    ser.serial.timeout = MB.timeout								
    ser.clear_buffers_before_call = MB.clear_buffers_before_call
    ser.clear_buffers_after_call = MB.clear_buffers_after_call

    while True:
        try:
            ser.debug = False  # Disable debug mode
            data = ser.read_registers(read_start, MB.read_length, 3)
            ser.serial.close()

            target = data[6] / 10.0
            output = data[0] / 10.0

            return target, output
            
            ## Refresh the command line table
            sleep(0.2)
            os.system('cls' if os.name == 'nt' else 'clear')

        except KeyboardInterrupt:
            break
