import minimalmodbus
import Modbus_Settings as MB
import rpm_poll as rp
import time

def read_rpm():
    max_retries = 10
    retry_delay = 1

    target = 1
    output = 1

    for attempt in range(max_retries):
        try:
            new_target, new_output = rp.poll_rpm()

            if new_target is not None and new_output is not None:
                target = new_target
                output = new_output
                return target, output

            print("Received None data. Retrying...")

        except minimalmodbus.ModbusException as e:
            print("Modbus error:", e)

        except Exception as e:
            print("Error:", e)

        time.sleep(retry_delay)

    print("Failed to read RPM values after multiple retries.")
    return target, output
