##########
'''MAIN SERVER CODE'''
##########

import os
import sys
import time
import math
import json
import socket
import logging
import threading
import numpy as np
import RPi.GPIO as GPIO
from datetime import datetime

from witmotion import IMU
from panel_lamp import check
import sensor_temp
import sensor_rpm

##CHECK
check(26) 
'''skema looping ngecek tiap second belum'''

#VIBRATION CALLBACK UPDATE
def callback(msg):
	global imu
	imu.get_acceleration()

def read_vib():
	imu.subscribe(callback)
	acc_radial = math.sqrt(((imu.last_a[0]**2) + (imu.last_a[1]**2)))
	return acc_radial

#VIBRATION IN DIFFERENT THREAD
#10Hz refers to the return of 10 data packets in 1S. 1 data packet is 33 bytes by default.
def vibration_list():
	global imu
	global timer
	global vib_list
	imu = IMU('/dev/ttySC1', 115200)
	imu.set_update_rate(200)
	while True:
		#APPEND VIB_LIST
		vib_list.append(read_vib())
		time.sleep(0.005)
		if (time.time()-timer) >= 1:
			#print(vib_list)
			#print(len(vib_list))
			#print(np.mean(vib_list))
			return vib_list

#SERVER DATA LIBRARY		
def collect_data():
	global vib_list
	temperature = 0.0
	rpm = 0.0
	temperature = sensor_temp.read_temp()
	rpm = sensor_rpm.read_rpm()
	print('bbb')
	data ={
		"LHL01":{
		"timestamp": datetime.now().isoformat("@", "seconds"),
		"performance_log": 
			{
			"temperature": temperature,
			#"rpm": rpm,
			"rpm":np.random.uniform(2800,2900),
			"vibration": ",".join(map(str, vib_list))
			}
		}
	}
	print(data)
	data = json.dumps(data)
	print(f"Length: {len(vib_list)}")
	return data
			
if __name__ == '__main__':
	global vib_list
	global timer
	global rekam 
	
	vib_list = []
	timer = time.time()
	
	vib_thread = threading.Thread(target = vibration_list)
	vib_thread.daemon = True
	vib_thread.start()
	
	data_thread = threading.Thread(target = collect_data)
	data_thread.daemon = True
	data_thread.start()

	while True:
		if (time.time()-timer) >= 1:
			collect_data()
			vib_list = []
			timer = time.time()
