##########
'''INVERTER MODBUS SETTINGS CODE'''
##########

mb_address = 1							
USB_port = "/dev/ttySC0"				
baudrate = 115200							
bytesize = 8							
stopbits = 1							
timeout = 0.1							
clear_buffers_before_call = True		
clear_buffers_after_call  = True		

'''target frequency modbus address'''
reading_offset = 44100 
 
'''output frequency modbus address'''
reading_offset_feedback = 44108 
read_length = 10
