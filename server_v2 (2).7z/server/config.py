##########
'''MAIN SERVER CODE'''
##########

# Server configuration
SERVER_IP = "10.129.9.48"
SERVER_PORT = 3333

# IMU configuration
IMU_PORT = '/dev/ttySC1'
IMU_BAUDRATE = 115200
IMU_UPDATERATE = 200

# Other configurations
VIBRATION_BUFFER_SIZE = 200
